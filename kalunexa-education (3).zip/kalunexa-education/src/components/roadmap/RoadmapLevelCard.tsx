import Link from "next/link";
import { Check } from "lucide-react";
import type { RoadmapLevel } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

/**
 * Satu kartu level di dalam roadmap. Statusnya ditunjukkan dengan
 * IKON + TEKS (bukan cuma warna), supaya tetap jelas bagi pengguna
 * yang sulit membedakan warna (aturan accessibility STEP 3 & 4).
 *
 * `href` bersifat opsional (ditambahkan STEP 5): kalau diisi, seluruh
 * kartu jadi tautan yang bisa diklik. Kalau kosong, kartu tetap
 * tampil sebagai pratinjau saja — dipakai untuk level yang isinya
 * belum ada (STEP 4: "belum perlu membuat seluruh materi bisa diklik").
 */
export function RoadmapLevelCard({
  level,
  href,
}: {
  level: RoadmapLevel;
  href?: string;
}) {
  const isDone = level.status === "selesai";
  const isComingSoon = level.status === "segera-hadir";

  const content = (
    <Card
      interactive={Boolean(href)}
      className={`flex flex-col gap-3 ${isComingSoon ? "opacity-70" : ""}`}
    >
      <div className="flex items-start justify-between gap-3">
        <span
          className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-button font-mono text-sm font-bold ${
            isDone
              ? "bg-primary-strong text-white"
              : "bg-primary-soft text-primary-strong"
          }`}
          aria-hidden="true"
        >
          {isDone ? <Check size={18} /> : level.number}
        </span>

        {isDone && (
          <Badge tone="primary">Selesai</Badge>
        )}
        {level.status === "berjalan" && <Badge tone="accent">Sedang dipelajari</Badge>}
        {isComingSoon && <Badge tone="neutral">Segera hadir</Badge>}
      </div>

      <div>
        <p className="text-xs font-medium text-muted">Level {level.number}</p>
        <h3 className="mt-0.5 text-base font-bold text-foreground">
          {level.title}
        </h3>
        <p className="mt-1 text-sm text-muted">{level.description}</p>
      </div>
    </Card>
  );

  if (href) {
    return (
      <Link href={href} className="block rounded-card focus-visible:outline-none">
        {content}
      </Link>
    );
  }

  return content;
}
