"use client";

import type { RoadmapLevel } from "@/lib/types";
import { useProgress } from "@/lib/progress-context";
import { getLevelLessons } from "@/lib/lessons";
import { RoadmapLevelCard } from "@/components/roadmap/RoadmapLevelCard";

/**
 * Membungkus <RoadmapLevelCard> (dibuat di STEP 4, dipakai lagi di
 * sini — TIDAK membuat kartu baru). STEP 6: digeneralisasi supaya
 * SETIAP level yang sudah punya data materi (bukan cuma Level 0 yang
 * di-hardcode seperti STEP 5) otomatis dapat status hidup dari
 * progress sungguhan dan bisa diklik. Level yang belum punya materi
 * tetap memakai status statis "segera-hadir" dari src/data/roadmap.ts.
 */
export function RoadmapLevelsWithLiveStatus({ levels }: { levels: RoadmapLevel[] }) {
  const { countComplete } = useProgress();

  const displayLevels = levels.map((level) => {
    const levelLessons = getLevelLessons(level.number);
    if (levelLessons.length === 0) return { ...level, hasLessons: false };

    const ids = levelLessons.map((l) => l.id);
    const done = countComplete(ids);

    const status: RoadmapLevel["status"] =
      done === 0 ? "belum-mulai" : done === ids.length ? "selesai" : "berjalan";

    return { ...level, status, hasLessons: true };
  });

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
      {displayLevels.map(({ hasLessons, ...level }) => (
        <RoadmapLevelCard
          key={level.number}
          level={level}
          href={hasLessons ? `/belajar/level-${level.number}` : undefined}
        />
      ))}
    </div>
  );
}
