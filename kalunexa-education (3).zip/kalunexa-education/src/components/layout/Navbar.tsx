import Link from "next/link";
import { mainNav } from "@/lib/navigation";
import { Logo } from "@/components/layout/Logo";
import { MobileMenu } from "@/components/layout/MobileMenu";
import { Button } from "@/components/ui/Button";

/**
 * Navbar dipakai di semua halaman lewat src/app/layout.tsx, bukan
 * ditulis ulang di tiap halaman. Tingginya sengaja pendek (56px)
 * supaya tidak memakan banyak ruang layar saat pengguna scroll,
 * dan "sticky" (menempel di atas) sesuai keputusan STEP 3.
 *
 * "Masuk" belum ditampilkan di STEP 4 karena login sungguhan baru
 * dibuat di tahap berikutnya (lihat STEP 2 & 3).
 */
export function Navbar() {
  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/95 backdrop-blur-sm">
      <div className="mx-auto flex h-14 max-w-page items-center justify-between px-5">
        <Logo />

        <nav className="hidden items-center gap-1 md:flex" aria-label="Navigasi utama">
          {mainNav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="rounded-button px-3 py-2 text-sm font-medium text-foreground hover:bg-surface-alt"
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="hidden md:block">
          <Button href="/belajar" className="px-4 py-2.5 text-sm">
            Mulai Belajar
          </Button>
        </div>

        <MobileMenu />
      </div>
    </header>
  );
}
