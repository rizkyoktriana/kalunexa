import Link from "next/link";

/**
 * Logo Kalunexa: kotak kecil bergaya "cell" Excel + nama website.
 * Dipakai di Navbar dan Footer, supaya identitasnya konsisten dan
 * kalau nanti mau diganti gambar logo asli, cukup ubah di satu file ini.
 */
export function Logo({ variant = "dark" }: { variant?: "dark" | "light" }) {
  const textColor = variant === "dark" ? "text-foreground" : "text-white";
  const subColor = variant === "dark" ? "text-muted" : "text-white/70";

  return (
    <Link href="/" className="flex items-center gap-2.5" aria-label="Kalunexa Education, kembali ke beranda">
      <span
        className="flex h-8 w-8 items-center justify-center rounded-[6px] bg-primary-strong font-mono text-sm font-bold text-white"
        aria-hidden="true"
      >
        K
      </span>
      <span className="flex flex-col leading-none">
        <span className={`text-[15px] font-bold ${textColor}`}>Kalunexa</span>
        <span className={`text-[11px] ${subColor}`}>Education</span>
      </span>
    </Link>
  );
}
