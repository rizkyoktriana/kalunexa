import Link from "next/link";
import { mainNav } from "@/lib/navigation";
import { Logo } from "@/components/layout/Logo";

/**
 * Footer sederhana: logo + tagline, daftar menu, dan copyright.
 * Sengaja dibuat ringkas (sesuai STEP 3 — "jangan terlalu besar").
 */
export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-border bg-surface-alt">
      <div className="mx-auto flex max-w-page flex-col gap-8 px-5 py-10 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <Logo />
          <p className="mt-3 max-w-xs text-sm text-muted">
            Learn Excel. Build Your Skills.
          </p>
        </div>

        <nav aria-label="Navigasi footer">
          <ul className="flex flex-col gap-2 sm:flex-row sm:gap-6">
            {mainNav.map((item) => (
              <li key={item.href}>
                <Link
                  href={item.href}
                  className="text-sm text-muted hover:text-foreground"
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
      </div>

      <div className="border-t border-border px-5 py-4">
        <p className="mx-auto max-w-page text-xs text-muted">
          © {year} Kalunexa Education.
        </p>
      </div>
    </footer>
  );
}
