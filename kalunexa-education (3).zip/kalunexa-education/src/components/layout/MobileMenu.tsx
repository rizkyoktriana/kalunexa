"use client";

import { useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { mainNav } from "@/lib/navigation";
import { Button } from "@/components/ui/Button";

/**
 * Menu untuk layar kecil (HP/tablet sempit): ikon tiga garis yang,
 * saat ditekan, membuka panel berisi semua menu memenuhi layar
 * (sesuai STEP 3 — item besar supaya mudah ditekan jempol).
 *
 * Dipisah jadi "use client" tersendiri supaya Navbar (di sekitarnya)
 * tetap bisa menjadi Server Component yang ringan; hanya bagian
 * interaktif ini yang berjalan di browser pengguna.
 */
export function MobileMenu() {
  const [open, setOpen] = useState(false);

  return (
    <div className="md:hidden">
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex h-10 w-10 items-center justify-center rounded-button text-foreground"
        aria-label="Buka menu navigasi"
        aria-expanded={open}
      >
        <Menu size={24} aria-hidden="true" />
      </button>

      {open && (
        <div className="fixed inset-0 z-50 flex flex-col bg-background">
          <div className="flex h-14 items-center justify-between border-b border-border px-5">
            <span className="text-[15px] font-bold text-foreground">Menu</span>
            <button
              type="button"
              onClick={() => setOpen(false)}
              className="flex h-10 w-10 items-center justify-center rounded-button text-foreground"
              aria-label="Tutup menu navigasi"
            >
              <X size={24} aria-hidden="true" />
            </button>
          </div>

          <nav className="flex flex-1 flex-col px-2 py-2">
            {mainNav.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                onClick={() => setOpen(false)}
                className="flex min-h-[56px] items-center rounded-button px-3 text-[17px] font-medium text-foreground hover:bg-surface-alt"
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="border-t border-border p-5">
            <Button href="/belajar" className="w-full" onClick={() => setOpen(false)}>
              Mulai Belajar
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
