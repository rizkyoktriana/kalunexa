"use client";

import { Check } from "lucide-react";
import type { Lesson } from "@/lib/types";
import { useProgress } from "@/lib/progress-context";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";
import { Button } from "@/components/ui/Button";
import { lessonHref } from "@/lib/lessons";

/**
 * Kartu satu materi di halaman overview level (STEP 5, bagian 3).
 * Tiga status: belum mulai, sedang dipelajari, selesai.
 * "Sedang dipelajari" dianggap materi PERTAMA yang belum selesai
 * secara urut — ini simulasi ringan tanpa perlu melacak "terakhir
 * dibuka", cukup untuk memberi arah tanpa sistem yang rumit.
 */
export function LessonCard({
  lesson,
  isNextUp,
}: {
  lesson: Lesson;
  isNextUp: boolean;
}) {
  const { isComplete } = useProgress();
  const done = isComplete(lesson.id);

  const status = done ? "selesai" : isNextUp ? "sedang-dipelajari" : "belum-mulai";

  return (
    <Card interactive className="flex items-center gap-4">
      <span
        className={`flex h-10 w-10 shrink-0 items-center justify-center rounded-button font-mono text-sm font-bold ${
          done
            ? "bg-primary-strong text-white"
            : "bg-primary-soft text-primary-strong"
        }`}
        aria-hidden="true"
      >
        {done ? <Check size={18} /> : String(lesson.order).padStart(2, "0")}
      </span>

      <div className="min-w-0 flex-1">
        <h3 className="truncate font-semibold text-foreground">{lesson.title}</h3>
        <p className="mt-0.5 truncate text-sm text-muted">{lesson.shortDescription}</p>
        <div className="mt-1.5 flex items-center gap-2">
          <Badge
            tone={done ? "primary" : status === "sedang-dipelajari" ? "accent" : "neutral"}
          >
            {done ? "Selesai" : status === "sedang-dipelajari" ? "Sedang dipelajari" : "Belum mulai"}
          </Badge>
          <span className="text-xs text-muted">{lesson.estimatedTime}</span>
        </div>
      </div>

      <Button href={lessonHref(lesson)} variant={done ? "secondary" : "primary"} className="shrink-0">
        {done ? "Pelajari Lagi" : "Mulai"}
      </Button>
    </Card>
  );
}
