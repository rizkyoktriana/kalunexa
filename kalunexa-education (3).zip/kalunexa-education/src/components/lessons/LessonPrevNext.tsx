import Link from "next/link";
import { ArrowLeft, ArrowRight } from "lucide-react";
import type { Lesson } from "@/lib/types";
import { lessonHref, levelHref } from "@/lib/lessons";

/**
 * Navigasi bebas materi sebelumnya/berikutnya, SELALU tampil di bawah
 * halaman materi apa pun status selesainya (lihat catatan keputusan UX
 * di halaman /belajar/level-0: level tidak dikunci, jadi navigasi
 * bebas ini juga tidak dikunci). Ini terpisah dari LessonCompletion,
 * yang isinya ajakan terarah setelah menekan "Sudah Paham".
 */
export function LessonPrevNext({
  level,
  previous,
  next,
}: {
  level: number;
  previous: Lesson | null;
  next: Lesson | null;
}) {
  return (
    <div className="flex items-center justify-between gap-4 border-t border-border pt-6">
      {previous ? (
        <Link
          href={lessonHref(previous)}
          className="flex min-h-[44px] items-center gap-1.5 rounded-button px-3 text-sm font-medium text-foreground hover:bg-surface-alt"
        >
          <ArrowLeft size={16} aria-hidden="true" />
          <span className="hidden sm:inline">{previous.title}</span>
          <span className="sm:hidden">Sebelumnya</span>
        </Link>
      ) : (
        <Link
          href={levelHref(level)}
          className="flex min-h-[44px] items-center gap-1.5 rounded-button px-3 text-sm font-medium text-foreground hover:bg-surface-alt"
        >
          <ArrowLeft size={16} aria-hidden="true" />
          Level {level}
        </Link>
      )}

      {next ? (
        <Link
          href={lessonHref(next)}
          className="flex min-h-[44px] items-center gap-1.5 rounded-button px-3 text-sm font-medium text-foreground hover:bg-surface-alt"
        >
          <span className="hidden sm:inline">{next.title}</span>
          <span className="sm:hidden">Berikutnya</span>
          <ArrowRight size={16} aria-hidden="true" />
        </Link>
      ) : (
        <Link
          href={levelHref(level)}
          className="flex min-h-[44px] items-center gap-1.5 rounded-button px-3 text-sm font-medium text-foreground hover:bg-surface-alt"
        >
          Level {level}
          <ArrowRight size={16} aria-hidden="true" />
        </Link>
      )}
    </div>
  );
}
