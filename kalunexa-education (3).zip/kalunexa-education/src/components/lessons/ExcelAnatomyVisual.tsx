/**
 * Visual sederhana untuk materi "Apa Itu Excel?" (STEP 5, bagian 7).
 * Tujuannya BUKAN mengajarkan ribbon/row/column/cell secara detail —
 * istilah-istilah itu punya materinya sendiri belakangan. Di sini
 * cukup membuat pemula mengenali: "oh, ini yang disebut Excel."
 */
export function ExcelAnatomyVisual({ caption }: { caption?: string }) {
  const columns = ["A", "B", "C", "D"];
  const rows = [1, 2, 3, 4];
  const captionText =
    caption ??
    "Begini kira-kira tampilan Excel: bagian atas berisi menu (ribbon), dan bagian bawah berisi kotak-kotak tabel yang siap diisi.";

  return (
    <figure aria-hidden="true">
      <div className="overflow-hidden rounded-card border border-border bg-card">
        {/* Ribbon / menu */}
        <div className="flex items-center gap-4 border-b border-border bg-surface-alt px-4 py-2.5">
          <span className="text-xs font-semibold text-foreground">Menu / Ribbon</span>
          <div className="flex gap-1.5">
            {[0, 1, 2].map((i) => (
              <span key={i} className="h-2 w-6 rounded-sm bg-border" />
            ))}
          </div>
        </div>

        {/* Grid tabel */}
        <div className="overflow-x-auto">
          <div className="grid min-w-[320px] grid-cols-[2rem_repeat(4,1fr)] font-mono text-xs">
            <div className="border-b border-r border-border bg-surface-alt p-2" />
            {columns.map((col) => (
              <div
                key={col}
                className="border-b border-r border-border bg-surface-alt p-2 text-center font-semibold text-muted last:border-r-0"
              >
                {col}
              </div>
            ))}

            {rows.map((row) => (
              <div className="contents" key={row}>
                <div className="border-b border-r border-border bg-surface-alt p-2 text-center text-muted">
                  {row}
                </div>
                {columns.map((col) => (
                  <div
                    key={col}
                    className="border-b border-r border-border p-3 last:border-r-0"
                  />
                ))}
              </div>
            ))}
          </div>
        </div>
      </div>

      <figcaption className="mt-3 text-sm text-muted">{captionText}</figcaption>
    </figure>
  );
}
