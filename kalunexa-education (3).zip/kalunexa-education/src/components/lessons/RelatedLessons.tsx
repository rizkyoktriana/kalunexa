import Link from "next/link";
import type { Lesson } from "@/lib/types";
import { lessonHref } from "@/lib/lessons";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

/**
 * "Materi Terkait" (STEP 6, bagian 16). Menerima Lesson[] yang SUDAH
 * dihitung oleh getRelatedLessons() di src/lib/lessons.ts — komponen
 * ini murni menampilkan, tidak tahu-menahu dari mana daftarnya berasal.
 * Relasinya berasal dari field `related` di data tiap materi (bukan
 * link yang di-hardcode di halaman), jadi menambah/mengubah materi
 * terkait cukup dilakukan di data. Kalau hasilnya kosong, komponen ini
 * tidak merender apa-apa (lihat pemanggilannya di halaman lesson).
 */
export function RelatedLessons({ lessons }: { lessons: Lesson[] }) {
  if (lessons.length === 0) return null;

  return (
    <div>
      <h2 className="text-lg font-bold text-foreground">Materi Terkait</h2>
      <div className="mt-4 grid gap-3 sm:grid-cols-3">
        {lessons.map((lesson) => (
          <Link key={lesson.id} href={lessonHref(lesson)} className="block">
            <Card interactive className="flex h-full flex-col gap-2">
              <span className="font-mono text-sm font-bold text-foreground">
                {lesson.title}
              </span>
              <p className="line-clamp-2 text-xs text-muted">{lesson.shortDescription}</p>
              <Badge tone="neutral" className="mt-auto w-fit">
                Level {lesson.level}
              </Badge>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
