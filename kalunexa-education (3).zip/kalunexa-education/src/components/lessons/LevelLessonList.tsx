"use client";

import type { Lesson } from "@/lib/types";
import { useProgress } from "@/lib/progress-context";
import { ProgressBar } from "@/components/ui/ProgressBar";
import { LessonCard } from "@/components/lessons/LessonCard";

/**
 * Digabung jadi satu komponen (bukan ProgressBar + list terpisah)
 * supaya "materi mana yang berstatus sedang dipelajari" dihitung
 * SEKALI di sini, lalu diteruskan ke tiap LessonCard — bukan setiap
 * kartu menghitung ulang sendiri-sendiri.
 */
export function LevelLessonList({ lessons }: { lessons: Lesson[] }) {
  const { isComplete, countComplete } = useProgress();

  const lessonIds = lessons.map((l) => l.id);
  const doneCount = countComplete(lessonIds);
  const percent = lessons.length > 0 ? Math.round((doneCount / lessons.length) * 100) : 0;

  // Materi "sedang dipelajari" = materi pertama secara urutan yang belum selesai.
  const firstIncompleteLesson = lessons.find((lesson) => !isComplete(lesson.id));
  const firstIncompleteOrder = firstIncompleteLesson?.order ?? null;

  return (
    <div>
      <div className="rounded-card border border-border bg-card p-5">
        <p className="text-sm font-medium text-foreground">
          {doneCount} dari {lessons.length} materi selesai
        </p>
        <ProgressBar
          percent={percent}
          className="mt-2"
          label={`${percent}% level ini selesai`}
        />
      </div>

      <div className="mt-6 flex flex-col gap-3">
        {lessons.map((lesson) => (
          <LessonCard
            key={lesson.id}
            lesson={lesson}
            isNextUp={lesson.order === firstIncompleteOrder}
          />
        ))}
      </div>
    </div>
  );
}
