import Link from "next/link";
import { ChevronRight } from "lucide-react";

export interface BreadcrumbItem {
  label: string;
  /** Kosongkan href untuk item terakhir (posisi saat ini, tidak bisa diklik) */
  href?: string;
}

/**
 * Breadcrumb sederhana. Item terakhir (tanpa href) ditandai
 * aria-current="page" supaya pembaca layar tahu itu posisi sekarang.
 */
export function Breadcrumb({ items }: { items: BreadcrumbItem[] }) {
  return (
    <nav aria-label="Posisi halaman" className="flex flex-wrap items-center gap-1.5 text-sm text-muted">
      {items.map((item, index) => {
        const isLast = index === items.length - 1;
        return (
          <span key={item.label} className="flex items-center gap-1.5">
            {item.href && !isLast ? (
              <Link href={item.href} className="hover:text-foreground hover:underline">
                {item.label}
              </Link>
            ) : (
              <span
                className={isLast ? "font-medium text-foreground" : ""}
                aria-current={isLast ? "page" : undefined}
              >
                {item.label}
              </span>
            )}
            {!isLast && <ChevronRight size={14} aria-hidden="true" />}
          </span>
        );
      })}
    </nav>
  );
}
