"use client";

import Link from "next/link";
import { Check, Circle } from "lucide-react";
import type { Lesson } from "@/lib/types";
import { useProgress } from "@/lib/progress-context";
import { lessonHref } from "@/lib/lessons";

interface LessonNavProps {
  levelLabel: string;
  lessons: Lesson[];
  currentSlug: string;
}

/**
 * Daftar materi satu level, dipakai sebagai penunjuk arah: sedang di
 * materi mana, mana yang sudah selesai, dan apa berikutnya (STEP 3 &
 * STEP 5, bagian 11). Ditulis SEKALI, lalu ditampilkan dua cara lewat
 * CSS saja (bukan dua komponen terpisah, supaya tidak ada kode ganda):
 *  - Desktop (lg ke atas): menempel sebagai sidebar, selalu terbuka.
 *  - Mobile/tablet: dibungkus <details>, tertutup secara default,
 *    memakai elemen HTML asli supaya bisa dibuka/tutup tanpa
 *    JavaScript tambahan.
 */
export function LessonNav({ levelLabel, lessons, currentSlug }: LessonNavProps) {
  const { isComplete } = useProgress();
  const currentIndex = lessons.findIndex((l) => l.slug === currentSlug);

  const list = (
    <ul className="flex flex-col gap-0.5">
      {lessons.map((lesson) => {
        const done = isComplete(lesson.id);
        const isCurrent = lesson.slug === currentSlug;

        return (
          <li key={lesson.id}>
            <Link
              href={lessonHref(lesson)}
              aria-current={isCurrent ? "page" : undefined}
              className={`flex items-center gap-2.5 rounded-button px-2.5 py-2 text-sm ${
                isCurrent
                  ? "bg-primary-soft font-medium text-primary-strong"
                  : "text-foreground hover:bg-surface-alt"
              }`}
            >
              {done ? (
                <Check size={16} className="shrink-0 text-primary-strong" aria-hidden="true" />
              ) : (
                <Circle size={16} className="shrink-0 text-border" aria-hidden="true" />
              )}
              <span className="truncate">{lesson.title}</span>
            </Link>
          </li>
        );
      })}
    </ul>
  );

  return (
    <>
      {/* Desktop: sidebar menempel, selalu terlihat */}
      <aside className="hidden w-64 shrink-0 lg:block">
        <div className="sticky top-20">
          <p className="px-2.5 text-xs font-semibold uppercase tracking-wide text-muted">
            {levelLabel}
          </p>
          <nav aria-label="Daftar materi" className="mt-3">
            {list}
          </nav>
        </div>
      </aside>

      {/* Mobile/tablet: panel yang bisa dibuka-tutup */}
      <details className="mb-6 rounded-card border border-border bg-card lg:hidden">
        <summary className="cursor-pointer list-none px-4 py-3 text-sm font-medium text-foreground">
          Daftar materi{" "}
          <span className="text-muted">
            (Materi {currentIndex + 1} dari {lessons.length})
          </span>
        </summary>
        <nav aria-label="Daftar materi" className="border-t border-border p-2">
          {list}
        </nav>
      </details>
    </>
  );
}
