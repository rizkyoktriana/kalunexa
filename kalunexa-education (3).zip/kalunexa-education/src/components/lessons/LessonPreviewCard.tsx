import Link from "next/link";
import type { LessonPreview } from "@/lib/types";
import { Card } from "@/components/ui/Card";
import { Badge } from "@/components/ui/Badge";

/**
 * Kartu materi/rumus, dipakai di section "Materi Populer" homepage
 * dan nanti juga di halaman Rumus (STEP 3, bagian 7).
 */
export function LessonPreviewCard({ lesson }: { lesson: LessonPreview }) {
  return (
    <Card interactive className="flex flex-col gap-3">
      <div className="flex items-center justify-between gap-2">
        <span className="font-mono text-base font-bold text-foreground">
          {lesson.name}
        </span>
        <Badge tone="neutral">{lesson.level}</Badge>
      </div>

      <p className="text-sm text-muted">{lesson.description}</p>

      <div className="mt-1 flex items-center justify-between gap-2">
        <Badge tone="primary">{lesson.category}</Badge>

        {lesson.available ? (
          <Link
            href={lesson.href ?? "/rumus"}
            className="text-sm font-medium text-primary-strong hover:underline underline-offset-4"
          >
            Pelajari
          </Link>
        ) : (
          <span className="text-sm text-muted">Segera hadir</span>
        )}
      </div>
    </Card>
  );
}
