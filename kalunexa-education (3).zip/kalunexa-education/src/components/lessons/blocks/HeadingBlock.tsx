/** Judul di dalam alur materi (bukan judul utama H1 halaman). Default H2. */
export function HeadingBlock({ text, level = 2 }: { text: string; level?: 2 | 3 }) {
  if (level === 3) {
    return <h3 className="text-base font-bold text-foreground">{text}</h3>;
  }
  return <h2 className="text-lg font-bold text-foreground">{text}</h2>;
}
