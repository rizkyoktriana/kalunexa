/** Kotak "Ringkasan" / "Yang Perlu Diingat" (STEP 5 & 6, bagian 15). */
export function SummaryBox({ points }: { points: string[] }) {
  return (
    <div className="rounded-card border border-border bg-surface-alt p-5">
      <h2 className="text-sm font-semibold text-foreground">Yang Perlu Diingat</h2>
      <ul className="mt-3 flex flex-col gap-2">
        {points.map((point) => (
          <li key={point} className="flex gap-2 text-sm text-foreground">
            <span className="text-primary-strong" aria-hidden="true">
              •
            </span>
            {point}
          </li>
        ))}
      </ul>
    </div>
  );
}
