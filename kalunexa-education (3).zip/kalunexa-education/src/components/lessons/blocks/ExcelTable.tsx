import type { TableData } from "@/lib/types";

/**
 * Menampilkan data tabel bergaya Excel. Dipakai oleh dua tempat:
 * blok "table" yang berdiri sendiri, dan di dalam blok "example"
 * (STEP 6, bagian 9). Ditulis SEKALI di sini supaya tampilannya
 * selalu konsisten di mana pun tabel muncul.
 *
 * Dibungkus `overflow-x-auto` sendiri (bukan seluruh halaman) supaya
 * tabel lebar di HP bisa digeser tanpa membuat seluruh halaman ikut
 * bergeser ke samping (STEP 6, bagian 28).
 */
export function ExcelTable({ headers, rows, caption }: TableData) {
  return (
    <div className="overflow-x-auto rounded-card border border-border">
      <table className="w-full min-w-[320px] border-collapse text-left text-sm">
        {caption && (
          <caption className="border-b border-border bg-surface-alt px-4 py-2 text-left text-xs font-medium text-muted caption-top">
            {caption}
          </caption>
        )}
        <thead>
          <tr className="bg-surface-alt">
            {headers.map((header) => (
              <th
                key={header}
                scope="col"
                className="border-b border-border px-4 py-2 font-mono text-xs font-semibold uppercase tracking-wide text-muted"
              >
                {header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {rows.map((row, rowIndex) => (
            <tr key={rowIndex} className="border-b border-border last:border-b-0">
              {row.map((cell, cellIndex) => (
                <td key={cellIndex} className="px-4 py-2 font-mono text-foreground">
                  {cell || <span className="text-muted">—</span>}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
