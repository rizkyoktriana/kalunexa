"use client";

import { useState } from "react";
import type { ReactNode } from "react";
import { Check, X } from "lucide-react";

interface QuizBlockRendererProps {
  question: string;
  options: string[];
  /** Index (mulai 0) dari `options` yang benar */
  answer: number;
  explanation: string;
}

/**
 * Satu pertanyaan quiz (STEP 6, bagian 14). Bedanya dari STEP 5:
 * sekarang quiz adalah SALAH SATU jenis blok konten (bisa ditaruh di
 * mana saja dalam urutan materi, dan boleh ada berapa pun jumlahnya —
 * 1, 3, atau 5), bukan array terpisah yang selalu muncul di akhir.
 *
 * Begitu satu opsi dipilih, jawaban langsung diperiksa dan
 * penjelasannya langsung tampil — sama seperti STEP 5, tetap sederhana
 * dan tanpa sistem nilai.
 */
export function QuizBlockRenderer({
  question,
  options,
  answer,
  explanation,
}: QuizBlockRendererProps) {
  const [selected, setSelected] = useState<number | null>(null);
  const revealed = selected !== null;
  const isCorrect = selected === answer;

  return (
    <div className="rounded-card border border-border bg-card p-5">
      <p className="font-medium text-foreground">{question}</p>

      <div className="mt-3 flex flex-col gap-2">
        {options.map((option, index) => {
          const isSelected = selected === index;
          const isCorrectOption = index === answer;

          let stateStyles = "border-border bg-card hover:border-primary-strong";
          let icon: ReactNode = null;

          if (revealed) {
            if (isCorrectOption) {
              stateStyles = "border-primary-strong bg-primary-soft";
              icon = <Check size={18} className="shrink-0 text-primary-strong" aria-hidden="true" />;
            } else if (isSelected) {
              stateStyles = "border-warning bg-warning-soft";
              icon = <X size={18} className="shrink-0 text-warning" aria-hidden="true" />;
            } else {
              stateStyles = "border-border bg-card opacity-60";
            }
          }

          return (
            <button
              key={option}
              type="button"
              onClick={() => setSelected(index)}
              disabled={revealed}
              aria-pressed={isSelected}
              className={`flex w-full items-center justify-between gap-3 rounded-input border px-4 py-3 text-left text-sm text-foreground transition-colors disabled:cursor-default ${stateStyles}`}
            >
              <span>{option}</span>
              {icon}
            </button>
          );
        })}
      </div>

      {revealed && (
        <p
          className={`mt-3 text-sm font-medium ${isCorrect ? "text-primary-strong" : "text-warning"}`}
          role="status"
        >
          {isCorrect ? "Benar. " : "Belum tepat. "}
          {explanation}
        </p>
      )}
    </div>
  );
}
