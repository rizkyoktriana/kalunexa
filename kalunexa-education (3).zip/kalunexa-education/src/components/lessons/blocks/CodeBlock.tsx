/**
 * Blok kode/teks monospace generik (STEP 6, bagian 3) — belum dipakai
 * di materi Excel manapun saat ini (rumus punya blok "formula" sendiri
 * yang lebih kaya), tapi disiapkan untuk kebutuhan lain nanti, misalnya
 * menampilkan kombinasi shortcut atau contoh path file.
 */
export function CodeBlock({ code, language }: { code: string; language?: string }) {
  return (
    <div className="overflow-x-auto rounded-card border border-border bg-surface-alt">
      {language && (
        <p className="border-b border-border px-4 py-1.5 text-xs font-medium text-muted">
          {language}
        </p>
      )}
      <pre className="px-4 py-3 font-mono text-sm text-foreground">
        <code>{code}</code>
      </pre>
    </div>
  );
}
