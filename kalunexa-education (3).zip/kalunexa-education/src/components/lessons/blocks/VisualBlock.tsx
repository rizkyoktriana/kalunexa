import { ExcelAnatomyVisual } from "@/components/lessons/ExcelAnatomyVisual";

/**
 * Menampilkan ilustrasi bernama. Dipetakan lewat "component" (bukan
 * mengirim JSX langsung dari data), supaya data lesson tetap berupa
 * data biasa (bisa disimpan sebagai JSON kalau nanti pindah ke
 * database) — bukan campur kode React di dalam data.
 */
export function VisualBlock({
  component,
  caption,
}: {
  component: "excel-anatomy";
  caption?: string;
}) {
  if (component === "excel-anatomy") {
    return <ExcelAnatomyVisual caption={caption} />;
  }
  return null;
}
