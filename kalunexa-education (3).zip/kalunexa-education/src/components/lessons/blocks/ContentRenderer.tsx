import type { ContentBlock } from "@/lib/types";
import { HeadingBlock } from "@/components/lessons/blocks/HeadingBlock";
import { GoalBlock } from "@/components/lessons/blocks/GoalBlock";
import { ParagraphBlock } from "@/components/lessons/blocks/ParagraphBlock";
import { VisualBlock } from "@/components/lessons/blocks/VisualBlock";
import { ImageBlock } from "@/components/lessons/blocks/ImageBlock";
import { ExcelTable } from "@/components/lessons/blocks/ExcelTable";
import { FormulaDisplay } from "@/components/lessons/blocks/FormulaDisplay";
import { ExampleBlock } from "@/components/lessons/blocks/ExampleBlock";
import { TipBox } from "@/components/lessons/blocks/TipBox";
import { WarningBox } from "@/components/lessons/blocks/WarningBox";
import { CodeBlock } from "@/components/lessons/blocks/CodeBlock";
import { QuizBlockRenderer } from "@/components/lessons/blocks/QuizBlockRenderer";
import { SummaryBox } from "@/components/lessons/blocks/SummaryBox";

/**
 * INTI SISTEM CONTENT-DRIVEN (STEP 6)
 * -------------------------------------
 * Ini "cetakannya". Fungsi ini menerima ARRAY BLOK apa pun (dari
 * materi mana pun, level mana pun) dan tahu persis komponen mana yang
 * harus dipanggil untuk tiap `type`. Menambah materi baru tidak pernah
 * menyentuh file ini — cukup menambah data yang formatnya sudah sesuai
 * salah satu tipe di bawah (lihat src/lib/types.ts: ContentBlock).
 *
 * Kalau suatu saat ada `type` baru yang belum dikenali di sini,
 * blok itu SENGAJA tidak ditampilkan apa-apa (bukan bikin halaman
 * error) — konsisten dengan prinsip STEP 6 bagian 25: lebih baik
 * sebagian tidak tampil daripada seluruh halaman rusak.
 */
export function ContentRenderer({ blocks }: { blocks: ContentBlock[] }) {
  return (
    <div className="flex flex-col gap-6">
      {blocks.map((block, index) => (
        <div key={index}>{renderBlock(block)}</div>
      ))}
    </div>
  );
}

function renderBlock(block: ContentBlock) {
  switch (block.type) {
    case "heading":
      return <HeadingBlock text={block.text} level={block.level} />;
    case "goal":
      return <GoalBlock text={block.text} />;
    case "paragraph":
      return <ParagraphBlock text={block.text} />;
    case "visual":
      return <VisualBlock component={block.component} caption={block.caption} />;
    case "image":
      return <ImageBlock src={block.src} alt={block.alt} caption={block.caption} />;
    case "table":
      return <ExcelTable headers={block.headers} rows={block.rows} caption={block.caption} />;
    case "formula":
      return (
        <FormulaDisplay formula={block.formula} result={block.result} parts={block.parts} />
      );
    case "example":
      return (
        <ExampleBlock
          title={block.title}
          situation={block.situation}
          table={block.table}
          formula={block.formula}
          result={block.result}
          explanation={block.explanation}
        />
      );
    case "tip":
      return <TipBox text={block.text} />;
    case "warning":
      return <WarningBox text={block.text} />;
    case "code":
      return <CodeBlock code={block.code} language={block.language} />;
    case "quiz":
      return (
        <QuizBlockRenderer
          question={block.question}
          options={block.options}
          answer={block.answer}
          explanation={block.explanation}
        />
      );
    case "summary":
      return <SummaryBox points={block.points} />;
    default:
      return null;
  }
}
