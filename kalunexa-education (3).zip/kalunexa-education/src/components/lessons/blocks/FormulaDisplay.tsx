"use client";

import { useState } from "react";
import { Copy, Check } from "lucide-react";
import type { FormulaPart } from "@/lib/types";

interface FormulaDisplayProps {
  formula: string;
  result?: string;
  parts?: FormulaPart[];
}

/**
 * Kotak formula (STEP 6, bagian 8 & 10): teks rumus dengan tombol
 * salin, hasil (kalau ada), dan penjelasan tiap bagian formula (kalau
 * ada — misalnya untuk rumus dengan beberapa argumen seperti XLOOKUP
 * nanti). Bagian `result` dan `parts` OPSIONAL: kalau datanya tidak
 * diisi, bagian itu tidak ditampilkan sama sekali (STEP 6, Validation).
 */
export function FormulaDisplay({ formula, result, parts }: FormulaDisplayProps) {
  const [copied, setCopied] = useState(false);

  async function handleCopy() {
    try {
      await navigator.clipboard.writeText(formula);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      // Clipboard tidak tersedia (jarang terjadi) — abaikan saja, tanpa mengganggu pengguna.
    }
  }

  return (
    <div className="rounded-card border border-border bg-card">
      <div className="flex items-center justify-between gap-3 overflow-x-auto px-4 py-3">
        <code className="whitespace-pre font-mono text-base text-foreground">{formula}</code>
        <button
          type="button"
          onClick={handleCopy}
          className="flex shrink-0 items-center gap-1.5 rounded-button px-2.5 py-1.5 text-xs font-medium text-muted hover:bg-surface-alt hover:text-foreground"
          aria-label="Salin rumus"
        >
          {copied ? (
            <>
              <Check size={14} aria-hidden="true" /> Disalin
            </>
          ) : (
            <>
              <Copy size={14} aria-hidden="true" /> Salin
            </>
          )}
        </button>
      </div>

      {result && (
        <div className="border-t border-border bg-primary-soft px-4 py-2.5 text-sm">
          <span className="text-muted">Hasil: </span>
          <span className="font-mono font-semibold text-primary-strong">{result}</span>
        </div>
      )}

      {parts && parts.length > 0 && (
        <dl className="flex flex-col gap-1.5 border-t border-border px-4 py-3">
          {parts.map((p) => (
            <div key={p.part} className="flex flex-wrap gap-2 text-sm">
              <dt className="shrink-0 font-mono font-semibold text-primary-strong">
                {p.part}
              </dt>
              <dd className="text-muted">= {p.meaning}</dd>
            </div>
          ))}
        </dl>
      )}
    </div>
  );
}
