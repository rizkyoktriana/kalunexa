import type { TableData } from "@/lib/types";
import { ExcelTable } from "@/components/lessons/blocks/ExcelTable";
import { FormulaDisplay } from "@/components/lessons/blocks/FormulaDisplay";

interface ExampleBlockProps {
  title?: string;
  situation: string;
  table?: TableData;
  formula?: string;
  result?: string;
  explanation?: string;
}

/**
 * "Contoh Kasus" (STEP 6, bagian 13): situasi + (opsional) data,
 * formula, hasil, dan penjelasan — supaya pengguna tidak cuma
 * menghafal rumus, tapi melihat kapan rumus itu dipakai.
 *
 * Semua bagian selain `situation` OPSIONAL. Materi "Apa Itu Excel?"
 * memakai blok ini hanya dengan `situation` terisi (empat kali, untuk
 * empat konteks berbeda) — membuktikan blok yang sama bisa dipakai
 * ringan (cuma satu kalimat) maupun lengkap (situasi + tabel + formula
 * + hasil), tergantung kebutuhan materi.
 */
export function ExampleBlock({
  title,
  situation,
  table,
  formula,
  result,
  explanation,
}: ExampleBlockProps) {
  return (
    <div className="rounded-card border border-border bg-card p-5">
      <p className="text-xs font-semibold uppercase tracking-wide text-primary-strong">
        Contoh Kasus{title ? ` — ${title}` : ""}
      </p>
      <p className="mt-2 text-sm text-foreground">{situation}</p>

      {table && (
        <div className="mt-4">
          <ExcelTable {...table} />
        </div>
      )}

      {formula && (
        <div className="mt-4">
          <FormulaDisplay formula={formula} result={result} />
        </div>
      )}

      {explanation && <p className="mt-4 text-sm text-muted">{explanation}</p>}
    </div>
  );
}
