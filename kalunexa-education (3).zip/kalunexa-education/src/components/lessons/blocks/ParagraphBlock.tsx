export function ParagraphBlock({ text }: { text: string }) {
  return <p className="text-base leading-relaxed text-foreground">{text}</p>;
}
