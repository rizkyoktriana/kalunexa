import { AlertTriangle } from "lucide-react";

/**
 * Kotak "Perlu diperhatikan" (STEP 6, bagian 12). Sengaja memakai
 * amber, BUKAN merah — merah di Kalunexa dikhususkan untuk error
 * sistem (keputusan desain STEP 3), bukan untuk hal yang perlu
 * diperhatikan pengguna saat belajar.
 */
export function WarningBox({ text }: { text: string }) {
  return (
    <div className="flex gap-3 rounded-card border border-warning bg-warning-soft p-4">
      <AlertTriangle size={20} className="mt-0.5 shrink-0 text-warning" aria-hidden="true" />
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-warning">
          Perlu diperhatikan
        </p>
        <p className="mt-1 text-sm text-foreground">{text}</p>
      </div>
    </div>
  );
}
