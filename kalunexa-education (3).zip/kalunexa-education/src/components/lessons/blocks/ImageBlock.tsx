/* eslint-disable @next/next/no-img-element */

/**
 * Blok gambar generik. Disiapkan strukturnya untuk STEP 6, meski belum
 * ada materi yang memakainya (belum ada aset gambar sungguhan). Kalau
 * `src` kosong, Validation rule STEP 6 bagian 25 berlaku: blok ini
 * tidak ditampilkan sama sekali (dicegah dari sisi tipe data, karena
 * `src` wajib diisi kalau blok "image" dipakai).
 */
export function ImageBlock({
  src,
  alt,
  caption,
}: {
  src: string;
  alt: string;
  caption?: string;
}) {
  return (
    <figure>
      <img src={src} alt={alt} className="w-full rounded-card border border-border" />
      {caption && <figcaption className="mt-2 text-sm text-muted">{caption}</figcaption>}
    </figure>
  );
}
