import { Lightbulb } from "lucide-react";

/** Kotak "Tips" (STEP 6, bagian 11). Warna kuning pucat, konsisten dengan STEP 3. */
export function TipBox({ text }: { text: string }) {
  return (
    <div className="flex gap-3 rounded-card border border-border bg-accent-soft p-4">
      <Lightbulb size={20} className="mt-0.5 shrink-0 text-warning" aria-hidden="true" />
      <div>
        <p className="text-xs font-semibold uppercase tracking-wide text-warning">Tips</p>
        <p className="mt-1 text-sm text-foreground">{text}</p>
      </div>
    </div>
  );
}
