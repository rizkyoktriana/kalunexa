/** Kotak "Setelah materi ini kamu bisa..." — biasanya blok pertama dalam satu materi. */
export function GoalBlock({ text }: { text: string }) {
  return (
    <div className="rounded-card border border-border bg-primary-soft p-4 text-sm text-primary-strong">
      {text}
    </div>
  );
}
