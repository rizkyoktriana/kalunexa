"use client";

import { ArrowRight } from "lucide-react";
import type { Lesson } from "@/lib/types";
import { useProgress } from "@/lib/progress-context";
import { Button } from "@/components/ui/Button";
import { lessonHref, levelHref } from "@/lib/lessons";

interface LessonCompletionProps {
  lesson: Lesson;
  next: Lesson | null;
  /** Semua id materi di level ini, untuk mengecek apakah levelnya sudah selesai semua */
  allLessonIdsInLevel: string[];
}

/**
 * Bagian paling penting untuk menjawab "harus klik apa setelah ini?"
 * (prinsip UX STEP 3). Sebelum ditekan: tombol "Sudah Paham". Setelah
 * ditekan: pesan selesai + arah yang jelas ke materi berikutnya (atau
 * ucapan selesai level, kalau ini materi terakhir).
 */
export function LessonCompletion({ lesson, next, allLessonIdsInLevel }: LessonCompletionProps) {
  const { isComplete, markComplete, markIncomplete, countComplete } = useProgress();
  const done = isComplete(lesson.id);
  const levelFullyDone = countComplete(allLessonIdsInLevel) === allLessonIdsInLevel.length;

  if (!done) {
    return (
      <div className="rounded-card border border-border bg-card p-5">
        <p className="text-sm text-muted">
          Sudah selesai membaca materi ini?
        </p>
        <div className="mt-3">
          <Button onClick={() => markComplete(lesson.id)}>Sudah Paham</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="rounded-card border border-primary-strong bg-primary-soft p-5">
      <p className="font-medium text-primary-strong">
        ✓ Materi selesai. Bagus, kamu sudah menyelesaikan materi ini.
      </p>

      {next ? (
        <div className="mt-4 flex flex-wrap items-center justify-between gap-3 rounded-card border border-border bg-card p-4">
          <div>
            <p className="text-xs text-muted">Materi berikutnya</p>
            <p className="font-medium text-foreground">{next.title}</p>
          </div>
          <Button href={lessonHref(next)} className="shrink-0">
            Lanjut Belajar <ArrowRight size={16} aria-hidden="true" />
          </Button>
        </div>
      ) : levelFullyDone ? (
        <div className="mt-4 rounded-card border border-border bg-card p-4">
          <p className="font-medium text-foreground">
            Level {lesson.level} selesai! Kamu sudah menyelesaikan semua materi di level ini.
          </p>
          <div className="mt-3">
            <Button href={levelHref(lesson.level)} variant="secondary">
              Kembali ke Level {lesson.level}
            </Button>
          </div>
        </div>
      ) : (
        <div className="mt-4">
          <Button href={levelHref(lesson.level)} variant="secondary">
            Kembali ke Level {lesson.level}
          </Button>
        </div>
      )}

      <button
        type="button"
        onClick={() => markIncomplete(lesson.id)}
        className="mt-4 text-xs text-muted hover:text-foreground hover:underline"
      >
        Tandai belum selesai
      </button>
    </div>
  );
}
