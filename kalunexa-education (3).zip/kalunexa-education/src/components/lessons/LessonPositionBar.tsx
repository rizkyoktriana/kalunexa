/**
 * Bar tipis di atas halaman materi (sesuai STEP 3, bagian 6), murni
 * menunjukkan POSISI ("Materi 2 dari 7"), bukan progress penyelesaian.
 * Karena hanya butuh urutan & total, komponen ini tidak perlu tahu
 * soal status selesai/belum — jadi bisa tetap Server Component.
 */
export function LessonPositionBar({
  levelLabel,
  order,
  total,
}: {
  levelLabel: string;
  order: number;
  total: number;
}) {
  const percent = Math.round((order / total) * 100);

  return (
    <div className="border-b border-border bg-surface-alt">
      <div className="h-1 w-full bg-border">
        <div
          className="h-full bg-primary-strong"
          style={{ width: `${percent}%` }}
        />
      </div>
      <p className="mx-auto max-w-page px-5 py-2 text-xs font-medium text-muted">
        {levelLabel} › Materi {order} dari {total}
      </p>
    </div>
  );
}
