import type { Lesson } from "@/lib/types";

/**
 * Ditampilkan untuk materi yang strukturnya sudah ada tapi isinya
 * belum ditulis (lesson.available === false). Sengaja BUKAN halaman
 * kosong terpisah — breadcrumb, sidebar, dan posisi tetap tampil,
 * supaya pengguna tidak kehilangan arah/konteks navigasi.
 *
 * Keputusan UX: materi ini tetap BISA DIBUKA (tidak dikunci/terkunci
 * dengan gembok), konsisten dengan keputusan STEP 1 & 3 bahwa semua
 * level dan materi terbuka tanpa syarat. Yang membedakan hanyalah
 * isinya belum tersedia, bukan aksesnya yang ditutup.
 */
export function LessonUnavailable({ lesson }: { lesson: Lesson }) {
  return (
    <div className="rounded-card border border-dashed border-border bg-surface-alt p-8 text-center">
      <p className="text-xs font-semibold uppercase tracking-wide text-muted">
        Segera hadir
      </p>
      <h1 className="mt-2 text-2xl font-bold text-foreground">{lesson.title}</h1>
      <p className="mx-auto mt-2 max-w-sm text-muted">
        {lesson.shortDescription} Materi ini sedang disiapkan dan akan
        menyusul menggunakan pola yang sama dengan materi lain yang sudah ada.
      </p>
    </div>
  );
}
