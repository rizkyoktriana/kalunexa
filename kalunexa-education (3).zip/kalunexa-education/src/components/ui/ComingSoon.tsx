import { Button } from "@/components/ui/Button";

/**
 * Placeholder sederhana untuk halaman yang menunya sudah ada di Navbar,
 * tapi isinya baru dibangun di tahap berikutnya (STEP 5 dan seterusnya).
 * Ini supaya tidak ada tautan yang menuju halaman kosong/error 404.
 */
export function ComingSoon({
  title,
  description,
}: {
  title: string;
  description: string;
}) {
  return (
    <div className="mx-auto flex max-w-page flex-col items-center px-5 py-24 text-center">
      <p className="text-xs font-semibold uppercase tracking-wide text-primary-strong">
        Segera hadir
      </p>
      <h1 className="mt-3 text-3xl font-bold text-foreground">{title}</h1>
      <p className="mt-3 max-w-md text-muted">{description}</p>
      <div className="mt-8">
        <Button href="/">Kembali ke Beranda</Button>
      </div>
    </div>
  );
}
