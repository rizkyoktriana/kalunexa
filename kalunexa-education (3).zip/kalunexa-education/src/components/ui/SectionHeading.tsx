/**
 * Judul section yang dipakai berulang di homepage (dan nanti halaman
 * lain): judul besar + satu kalimat deskripsi kecil di bawahnya.
 *
 * `align` mengatur apakah judul rata tengah (dipakai di homepage) atau
 * rata kiri (nanti dipakai di halaman seperti Rumus atau Shortcut).
 */
interface SectionHeadingProps {
  title: string;
  description?: string;
  align?: "center" | "left";
}

export function SectionHeading({
  title,
  description,
  align = "center",
}: SectionHeadingProps) {
  const alignment = align === "center" ? "text-center mx-auto" : "text-left";

  return (
    <div className={`max-w-2xl ${alignment}`}>
      <h2 className="text-2xl font-bold text-foreground sm:text-[32px]">
        {title}
      </h2>
      {description && (
        <p className="mt-3 text-base text-muted sm:text-lg">{description}</p>
      )}
    </div>
  );
}
