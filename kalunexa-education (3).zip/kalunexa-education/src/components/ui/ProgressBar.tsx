/**
 * Bar progress generik: dipakai di halaman Level dan nanti Dashboard.
 * `percent` sudah dihitung di luar komponen ini (0-100).
 */
interface ProgressBarProps {
  percent: number;
  label?: string;
  className?: string;
}

export function ProgressBar({ percent, label, className = "" }: ProgressBarProps) {
  const clamped = Math.min(100, Math.max(0, percent));

  return (
    <div className={className}>
      <div
        className="h-2 w-full overflow-hidden rounded-full bg-surface-alt"
        role="progressbar"
        aria-valuenow={clamped}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={label ?? `Progress ${clamped}%`}
      >
        <div
          className="h-full rounded-full bg-primary-strong transition-[width] duration-300"
          style={{ width: `${clamped}%` }}
        />
      </div>
      {label && <p className="mt-2 text-sm text-muted">{label}</p>}
    </div>
  );
}
