import type { ReactNode } from "react";

/**
 * Label kecil untuk status atau kategori, contoh: "Level 3", "Selesai",
 * "Segera hadir". Sengaja tidak hanya mengandalkan warna — teksnya
 * sendiri sudah menjelaskan artinya (aturan accessibility di STEP 3).
 */
type BadgeTone = "neutral" | "primary" | "accent";

interface BadgeProps {
  children: ReactNode;
  tone?: BadgeTone;
  className?: string;
}

const toneStyles: Record<BadgeTone, string> = {
  neutral: "bg-surface-alt text-muted",
  primary: "bg-primary-soft text-primary-strong",
  accent: "bg-accent-soft text-warning",
};

export function Badge({ children, tone = "neutral", className = "" }: BadgeProps) {
  return (
    <span
      className={`inline-flex items-center rounded-badge px-2.5 py-1 text-xs font-medium ${toneStyles[tone]} ${className}`}
    >
      {children}
    </span>
  );
}
