import Link from "next/link";
import type { ButtonHTMLAttributes, ReactNode } from "react";

/**
 * Tombol serbaguna dengan 3 gaya (sesuai aturan STEP 3: hanya satu
 * tombol "utama" per layar):
 *
 *  - primary  : latar hijau tua, teks putih. Aksi paling penting.
 *  - secondary: garis tepi hijau, latar transparan. Aksi kedua.
 *  - ghost    : hanya teks + garis bawah saat hover. Aksi ringan/tersier.
 *
 * Bisa dipakai sebagai <button> biasa, atau sebagai link (beri prop `href`).
 */

type ButtonVariant = "primary" | "secondary" | "ghost" | "inverted";

interface BaseProps {
  variant?: ButtonVariant;
  children: ReactNode;
  className?: string;
}

type ButtonAsButton = BaseProps &
  ButtonHTMLAttributes<HTMLButtonElement> & {
    href?: undefined;
  };

type ButtonAsLink = BaseProps & {
  href: string;
  onClick?: () => void;
};

type ButtonProps = ButtonAsButton | ButtonAsLink;

const variantStyles: Record<ButtonVariant, string> = {
  primary:
    "bg-primary-strong text-white hover:bg-primary-deep active:bg-primary-deep",
  secondary:
    "border border-primary-strong text-primary-strong bg-transparent hover:bg-primary-soft",
  ghost: "text-primary-strong hover:underline underline-offset-4",
  // Dipakai di atas latar berwarna (contoh: CTA hijau), supaya tombolnya tetap terbaca.
  inverted: "bg-white text-primary-strong hover:bg-white/90",
};

const baseStyles =
  "inline-flex items-center justify-center gap-2 rounded-button px-5 py-3 text-[15px] font-medium " +
  "transition-colors duration-150 min-h-[44px] " +
  "disabled:opacity-50 disabled:pointer-events-none";

export function Button(props: ButtonProps) {
  const { variant = "primary", children, className = "" } = props;
  const styles = `${baseStyles} ${variantStyles[variant]} ${className}`;

  if ("href" in props && props.href) {
    return (
      <Link href={props.href} className={styles} onClick={props.onClick}>
        {children}
      </Link>
    );
  }

  const { href: _href, variant: _variant, className: _className, ...rest } =
    props as ButtonAsButton;

  return (
    <button className={styles} {...rest}>
      {children}
    </button>
  );
}
