import type { ReactNode } from "react";

/**
 * Kartu dasar: latar putih, garis tepi tipis, sudut membulat, bayangan
 * hampir tidak ada (sesuai STEP 3 — supaya tidak terlihat berat).
 *
 * Ini adalah "pembungkus" generik. Kartu yang lebih khusus, seperti
 * RoadmapLevelCard dan LessonPreviewCard, dibangun DI ATAS komponen ini,
 * supaya gaya kartunya tetap konsisten di seluruh website.
 */
interface CardProps {
  children: ReactNode;
  className?: string;
  /** Beri true kalau kartu ini bisa diklik/hover (menambah efek naik halus) */
  interactive?: boolean;
}

export function Card({ children, className = "", interactive = false }: CardProps) {
  return (
    <div
      className={`rounded-card border border-border bg-card p-6 shadow-soft ${
        interactive
          ? "transition-shadow duration-150 hover:shadow-hover"
          : ""
      } ${className}`}
    >
      {children}
    </div>
  );
}
