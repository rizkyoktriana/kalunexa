import { lessonPreviews } from "@/data/lessons";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { LessonPreviewCard } from "@/components/lessons/LessonPreviewCard";
import { Button } from "@/components/ui/Button";

/**
 * Section "Materi Populer" (STEP 3, section 6 / STEP 4 poin 11).
 * Datanya dari src/data/lessons.ts — data sementara, bukan database.
 */
export function LessonsPreview() {
  return (
    <section className="bg-surface-alt">
      <div className="mx-auto max-w-page px-5 py-16 sm:py-20">
        <SectionHeading
          title="Lagi cari sesuatu?"
          description="Rumus yang paling sering dicari orang."
        />

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {lessonPreviews.map((lesson) => (
            <LessonPreviewCard key={lesson.name} lesson={lesson} />
          ))}
        </div>

        <div className="mt-10 text-center">
          <Button href="/rumus" variant="secondary">
            Lihat Semua Rumus
          </Button>
        </div>
      </div>
    </section>
  );
}
