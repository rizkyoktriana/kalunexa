import { roadmapLevels } from "@/data/roadmap";
import { SectionHeading } from "@/components/ui/SectionHeading";
import { RoadmapLevelCard } from "@/components/roadmap/RoadmapLevelCard";
import { Button } from "@/components/ui/Button";

/**
 * Menampilkan 4 level pertama sebagai contoh, sesuai instruksi STEP 4
 * ("untuk sementara belum perlu membuat seluruh materi bisa diklik,
 * fokus pada tampilan dan struktur"). Data lengkapnya (10 level) ada
 * di src/data/roadmap.ts dan akan dipakai penuh di halaman /belajar.
 */
export function RoadmapPreview() {
  const preview = roadmapLevels.slice(0, 4);

  return (
    <section id="roadmap" className="bg-background">
      <div className="mx-auto max-w-page px-5 py-16 sm:py-20">
        <SectionHeading
          title="Dari nol sampai siap kerja, satu jalur"
          description="10 level yang disusun berurutan. Kamu selalu tahu sedang di mana."
        />

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {preview.map((level) => (
            <RoadmapLevelCard key={level.number} level={level} />
          ))}
        </div>

        <div className="mt-10 text-center">
          <Button href="/belajar" variant="secondary">
            Lihat Roadmap Lengkap
          </Button>
        </div>
      </div>
    </section>
  );
}
