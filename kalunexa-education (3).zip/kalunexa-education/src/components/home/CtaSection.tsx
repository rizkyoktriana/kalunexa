import { Button } from "@/components/ui/Button";

/**
 * CTA penutup (STEP 3, section 8). Ini satu-satunya blok hijau penuh
 * di homepage, sengaja dibuat menonjol karena ini ajakan terakhir
 * sebelum pengunjung sampai ke footer.
 */
export function CtaSection() {
  return (
    <section className="bg-primary-strong">
      <div className="mx-auto max-w-page px-5 py-16 text-center sm:py-20">
        <h2 className="text-2xl font-bold text-white sm:text-[32px]">
          Siap mulai? Level 0 cuma sekitar 15 menit.
        </h2>
        <p className="mt-3 text-base text-white/80 sm:text-lg">
          Tidak perlu daftar. Buka, baca, coba.
        </p>
        <div className="mt-8">
          <Button href="/belajar/level-0" variant="inverted">
            Mulai dari Level 0
          </Button>
        </div>
      </div>
    </section>
  );
}
