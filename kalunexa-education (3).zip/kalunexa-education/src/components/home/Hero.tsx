import { Button } from "@/components/ui/Button";

/**
 * Bagian pertama yang dilihat pengunjung. Headline dan copywriting
 * mengikuti hasil STEP 3 (bagian 4: alternatif headline nomor 1),
 * dipilih karena menenangkan pemula yang belum pernah pakai Excel.
 */
export function Hero() {
  return (
    <section className="border-b border-border bg-background">
      <div className="mx-auto grid max-w-page items-center gap-10 px-5 py-14 sm:py-20 md:grid-cols-2 md:gap-12">
        <div>
          <p className="text-xs font-semibold uppercase tracking-wide text-primary-strong">
            Learn Excel. Build Your Skills.
          </p>

          <h1 className="mt-4 text-4xl font-bold leading-tight text-foreground sm:text-5xl">
            Belajar Excel dari nol. Pelan-pelan, pasti bisa.
          </h1>

          <p className="mt-5 max-w-md text-lg text-muted">
            Dari belum pernah buka Excel sampai siap dipakai untuk kuliah,
            magang, dan kerja. Tanpa istilah rumit.
          </p>

          <div className="mt-8 flex flex-wrap items-center gap-4">
            <Button href="/belajar/level-0">Mulai dari Level 0</Button>
            <Button href="#roadmap" variant="ghost">
              Lihat Roadmap
            </Button>
          </div>

          <p className="mt-4 text-sm text-muted">
            Tanpa perlu daftar · Sekitar 10 menit per materi
          </p>
        </div>

        <div
          className="rounded-card border border-border bg-card p-5 shadow-soft"
          aria-hidden="true"
        >
          <ExcelSnippet />
        </div>
      </div>
    </section>
  );
}

/**
 * Potongan tabel bergaya Excel, sesuai keputusan STEP 3: motif visual
 * khas Kalunexa adalah "kotak-kotak Excel", bukan ilustrasi orang.
 * Ini satu-satunya elemen dekoratif besar di hero.
 */
function ExcelSnippet() {
  const rows = [
    { label: "Beras", value: "60.000" },
    { label: "Minyak", value: "35.000" },
    { label: "Telur", value: "28.000" },
  ];

  return (
    <div className="overflow-hidden rounded-input border border-border font-mono text-sm">
      <div className="grid grid-cols-[2rem_1fr_1fr] bg-surface-alt text-xs font-semibold text-muted">
        <div className="border-b border-r border-border p-2 text-center"> </div>
        <div className="border-b border-r border-border p-2">A</div>
        <div className="border-b border-border p-2">B</div>
      </div>

      <div className="grid grid-cols-[2rem_1fr_1fr]">
        <div className="border-b border-r border-border p-2 text-center text-xs text-muted">
          1
        </div>
        <div className="border-b border-r border-border p-2 text-foreground">
          Barang
        </div>
        <div className="border-b border-border p-2 text-foreground">Harga</div>
      </div>

      {rows.map((row, i) => (
        <div className="grid grid-cols-[2rem_1fr_1fr]" key={row.label}>
          <div className="border-b border-r border-border p-2 text-center text-xs text-muted">
            {i + 2}
          </div>
          <div className="border-b border-r border-border p-2 text-foreground">
            {row.label}
          </div>
          <div className="border-b border-border p-2 text-foreground">
            {row.value}
          </div>
        </div>
      ))}

      <div className="grid grid-cols-[2rem_1fr_1fr]">
        <div className="border-r border-border p-2 text-center text-xs text-muted">
          5
        </div>
        <div className="border-r border-border p-2 font-semibold text-foreground">
          Total
        </div>
        <div className="bg-accent-soft p-2 font-semibold text-primary-strong">
          123.000
        </div>
      </div>
    </div>
  );
}
