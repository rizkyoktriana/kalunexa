import { SectionHeading } from "@/components/ui/SectionHeading";
import { Card } from "@/components/ui/Card";

const points = [
  {
    title: "Buka Excel, lalu bingung mau ngapain",
    description: "Kotak-kotak di mana-mana, tidak jelas mulai dari mana.",
  },
  {
    title: "Tutorial-nya loncat-loncat",
    description: "Baru belajar dasar, tiba-tiba sudah rumus rumit.",
  },
  {
    title: "Tahu rumusnya, tapi kapan dipakai?",
    description: "Contohnya jauh dari tugas kuliah atau pekerjaanmu.",
  },
];

/**
 * Section "Masalah pengguna" dari STEP 3 (bagian 3, section 2).
 * Tujuannya membuat pengunjung merasa dimengerti sebelum diajak lanjut.
 */
export function Introduction() {
  return (
    <section className="bg-surface-alt">
      <div className="mx-auto max-w-page px-5 py-16 sm:py-20">
        <SectionHeading
          title="Familiar dengan ini?"
          description="Hampir semua orang mulai belajar Excel dengan cara yang sama: bingung."
        />

        <div className="mt-10 grid gap-4 sm:grid-cols-3">
          {points.map((point) => (
            <Card key={point.title}>
              <h3 className="font-semibold text-foreground">{point.title}</h3>
              <p className="mt-2 text-sm text-muted">{point.description}</p>
            </Card>
          ))}
        </div>

        <p className="mt-10 text-center text-base font-medium text-foreground">
          Di Kalunexa: satu jalur, satu langkah kecil, satu contoh nyata.
        </p>
      </div>
    </section>
  );
}
