import type { Lesson } from "@/lib/types";

/**
 * MATERI LEVEL 3 — RUMUS DASAR
 * -----------------------------
 * Tiga materi ini dibuat khusus untuk MEMBUKTIKAN sistem STEP 6:
 * satu template halaman (src/app/belajar/[level]/[slug]/page.tsx)
 * menampilkan tiga materi yang judul, penjelasan, formula, contoh,
 * dan quiz-nya SEMUA berbeda, tanpa satu pun halaman React baru
 * dibuat manual per materi.
 *
 * Sengaja susunan bloknya dibuat TIDAK SERAGAM antara SUM, AVERAGE,
 * dan COUNT (lihat komentar di tiap lesson) — supaya benar-benar
 * kelihatan bahwa `content` itu fleksibel per materi, bukan template
 * kaku yang mewajibkan blok yang sama di semua materi.
 */
export const level3Lessons: Lesson[] = [
  {
    id: "level-3/sum",
    slug: "sum",
    level: 3,
    category: "Rumus Dasar",
    title: "SUM",
    description:
      "Belajar SUM, rumus Excel untuk menjumlahkan sekumpulan angka secara otomatis.",
    shortDescription: "Menjumlahkan data dengan cepat, tanpa kalkulator.",
    order: 1,
    estimatedTime: "6 menit",
    difficulty: "Pemula",
    tags: ["sum", "jumlah", "rumus dasar"],
    keywords: ["rumus sum excel", "cara menjumlahkan di excel", "sum adalah"],
    available: true,
    related: [
      { level: 3, slug: "average" },
      { level: 3, slug: "count" },
    ],
    // Susunan: penjelasan → formula (dengan bagian) → contoh tabel →
    // contoh penggunaan (blok "example" gabungan) → tip → peringatan → quiz → ringkasan.
    content: [
      {
        type: "goal",
        text: "Setelah materi ini, kamu bisa menjumlahkan banyak angka sekaligus tanpa menghitung manual satu per satu.",
      },
      {
        type: "paragraph",
        text: "SUM adalah rumus Excel paling dasar dan paling sering dipakai. Fungsinya sederhana: menjumlahkan angka-angka yang kamu pilih. Daripada mengetik satu per satu dengan tanda tambah (+), kamu cukup memberi tahu Excel dari kotak mana sampai kotak mana yang mau dijumlahkan.",
      },
      {
        type: "paragraph",
        text: "SUM cocok dipakai kapan saja kamu punya sekumpulan angka dalam satu kolom atau baris: total penjualan, total pengeluaran, total stok, sampai total nilai ujian.",
      },
      {
        type: "formula",
        formula: "=SUM(range)",
        parts: [
          {
            part: "range",
            meaning: "kotak-kotak yang mau dijumlahkan, contoh B2:B10",
          },
        ],
      },
      {
        type: "table",
        caption: "Contoh data penjualan",
        headers: ["Nama", "Penjualan"],
        rows: [
          ["Andi", "100"],
          ["Budi", "150"],
          ["Citra", "200"],
        ],
      },
      {
        type: "formula",
        formula: "=SUM(B2:B4)",
        result: "450",
        parts: [
          {
            part: "B2:B4",
            meaning: "kotak-kotak berisi angka penjualan Andi, Budi, dan Citra",
          },
        ],
      },
      {
        type: "example",
        title: "Total Belanja Bulanan",
        situation:
          "Kamu mencatat belanja bulan ini dan ingin tahu totalnya tanpa menjumlahkan manual satu per satu.",
        table: {
          headers: ["Barang", "Harga"],
          rows: [
            ["Beras", "60.000"],
            ["Minyak", "35.000"],
            ["Telur", "28.000"],
          ],
        },
        formula: "=SUM(B2:B4)",
        result: "123.000",
        explanation:
          "SUM menjumlahkan semua angka dari B2 sampai B4 sekaligus — hasilnya langsung muncul, tanpa kalkulator.",
      },
      {
        type: "tip",
        text: "Kalau kamu sering menjumlahkan data dalam satu kolom, SUM jauh lebih cepat daripada menghitung satu per satu — apalagi kalau datanya sampai ratusan baris.",
      },
      {
        type: "warning",
        text: "Pastikan range yang kamu pilih benar-benar mencakup seluruh data. Kalau ada baris yang terlewat, hasilnya jadi tidak akurat.",
      },
      {
        type: "quiz",
        question: "Rumus manakah yang benar untuk menjumlahkan data dari B2 sampai B10?",
        options: ["=SUM(B2:B10)", "=TOTAL(B2:B10)", "=ADD(B2-B10)", "=SUM[B2:B10]"],
        answer: 0,
        explanation:
          "Rumus Excel selalu diawali tanda \"=\", diikuti nama fungsi dan kurung, misalnya =SUM(B2:B10).",
      },
      {
        type: "quiz",
        question:
          "Penjualan Andi, Budi, dan Citra masing-masing 100, 150, dan 200. Berapa hasil =SUM dari ketiganya?",
        options: ["350", "450", "500", "300"],
        answer: 1,
        explanation: "100 + 150 + 200 = 450.",
      },
      {
        type: "summary",
        points: [
          "SUM digunakan untuk menjumlahkan angka.",
          "Bisa digunakan untuk satu range sekaligus, misalnya B2:B10.",
          "Syntax dasar: =SUM(range)",
          "Cocok untuk total penjualan, stok, nilai, dan sebagainya.",
        ],
      },
    ],
  },
  {
    id: "level-3/average",
    slug: "average",
    level: 3,
    category: "Rumus Dasar",
    title: "AVERAGE",
    description:
      "Belajar AVERAGE, rumus Excel untuk menghitung rata-rata sekumpulan angka.",
    shortDescription: "Menghitung rata-rata angka secara otomatis.",
    order: 2,
    estimatedTime: "5 menit",
    difficulty: "Pemula",
    tags: ["average", "rata-rata", "rumus dasar"],
    keywords: ["rumus average excel", "cara menghitung rata-rata excel"],
    available: true,
    related: [
      { level: 3, slug: "sum" },
      { level: 3, slug: "count" },
    ],
    // Sengaja lebih ringkas dari SUM: tanpa blok tabel maupun "example"
    // terpisah, untuk membuktikan blok-blok itu memang OPSIONAL, bukan
    // wajib ada di setiap materi.
    content: [
      {
        type: "goal",
        text: "Setelah materi ini, kamu bisa menghitung rata-rata sekumpulan angka, bukan cuma totalnya.",
      },
      {
        type: "paragraph",
        text: "Kalau SUM menjumlahkan, AVERAGE menghitung rata-rata. Excel otomatis menjumlahkan semua angka lalu membaginya dengan jumlah datanya — kamu tidak perlu menghitung dua langkah itu sendiri.",
      },
      {
        type: "paragraph",
        text: "AVERAGE sering dipakai untuk melihat gambaran umum dari sekumpulan angka: rata-rata nilai ujian satu kelas, rata-rata penjualan harian, atau rata-rata pengeluaran per bulan.",
      },
      {
        type: "formula",
        formula: "=AVERAGE(range)",
        parts: [
          {
            part: "range",
            meaning: "kotak-kotak berisi angka yang mau dirata-ratakan, contoh B2:B10",
          },
        ],
      },
      {
        type: "tip",
        text: "AVERAGE otomatis mengabaikan kotak yang kosong — kotak kosong tidak dihitung sebagai nol, jadi hasilnya tetap akurat.",
      },
      {
        type: "quiz",
        question: "Ada 3 nilai ujian: 80, 90, dan 70. Berapa hasil AVERAGE-nya?",
        options: ["80", "70", "240", "90"],
        answer: 0,
        explanation: "(80 + 90 + 70) ÷ 3 = 80.",
      },
      {
        type: "summary",
        points: [
          "AVERAGE menghitung rata-rata dari sekumpulan angka.",
          "Syntax dasar: =AVERAGE(range)",
          "Kotak kosong tidak ikut dihitung sebagai nol.",
          "Cocok untuk rata-rata nilai, rata-rata penjualan harian, dan sejenisnya.",
        ],
      },
    ],
  },
  {
    id: "level-3/count",
    slug: "count",
    level: 3,
    category: "Rumus Dasar",
    title: "COUNT",
    description:
      "Belajar COUNT, rumus Excel untuk menghitung berapa banyak kotak yang berisi angka.",
    shortDescription: "Menghitung jumlah data yang terisi angka.",
    order: 3,
    estimatedTime: "5 menit",
    difficulty: "Pemula",
    tags: ["count", "hitung", "rumus dasar"],
    keywords: ["rumus count excel", "cara menghitung jumlah data excel"],
    available: true,
    related: [
      { level: 3, slug: "sum" },
      { level: 3, slug: "average" },
    ],
    // Susunan ketiga yang berbeda lagi: memakai SATU blok "example"
    // gabungan (situasi + tabel + formula + hasil + penjelasan jadi
    // satu), bukan tabel dan formula terpisah seperti di materi SUM.
    content: [
      {
        type: "goal",
        text: "Setelah materi ini, kamu bisa menghitung berapa banyak data yang sudah terisi, tanpa menghitung manual satu per satu.",
      },
      {
        type: "paragraph",
        text: "COUNT menghitung berapa banyak kotak yang berisi ANGKA — bukan menjumlahkan isinya, hanya menghitung jumlah kotaknya.",
      },
      {
        type: "warning",
        text: "COUNT hanya menghitung kotak yang berisi angka. Kalau datamu berupa nama atau teks, COUNT akan mengabaikannya (fungsi untuk menghitung teks dibahas di materi lain).",
      },
      {
        type: "example",
        title: "Menghitung Jumlah Siswa yang Sudah Mengumpulkan Tugas",
        situation:
          "Kamu punya daftar nilai siswa. Sebagian sudah mengumpulkan tugas (ada angka nilainya), sebagian belum (kotaknya masih kosong). Kamu ingin tahu berapa siswa yang sudah mengumpulkan.",
        table: {
          headers: ["Nama", "Nilai"],
          rows: [
            ["Andi", "85"],
            ["Budi", ""],
            ["Citra", "90"],
            ["Dedi", ""],
          ],
        },
        formula: "=COUNT(B2:B5)",
        result: "2",
        explanation:
          "COUNT hanya menghitung kotak berisi angka. Karena kotak Budi dan Dedi masih kosong, hasilnya 2 — hanya Andi dan Citra yang dihitung.",
      },
      {
        type: "quiz",
        question:
          "Dari 5 kotak, 3 di antaranya berisi angka dan 2 kotak kosong. Berapa hasil COUNT-nya?",
        options: ["5", "3", "2", "0"],
        answer: 1,
        explanation: "COUNT hanya menghitung kotak berisi angka, jadi hasilnya 3.",
      },
      {
        type: "summary",
        points: [
          "COUNT menghitung jumlah kotak yang berisi ANGKA.",
          "Kotak kosong atau berisi teks tidak ikut dihitung.",
          "Syntax dasar: =COUNT(range)",
          "Cocok untuk menghitung berapa banyak data yang sudah terisi.",
        ],
      },
    ],
  },
];
