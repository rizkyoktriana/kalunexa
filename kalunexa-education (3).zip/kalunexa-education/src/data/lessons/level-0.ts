import type { Lesson } from "@/lib/types";

/**
 * MATERI LEVEL 0 — KENALAN DENGAN EXCEL
 * --------------------------------------
 * Mulai STEP 6, `content` berupa ARRAY BLOK (lihat ContentBlock di
 * src/lib/types.ts), bukan objek dengan field tetap seperti STEP 5.
 * Ini yang membuat satu materi bisa punya susunan berbeda dari materi
 * lain — lihat perbandingan dengan src/data/lessons/level-3.ts (materi
 * SUM/AVERAGE/COUNT), yang urutan bloknya sengaja berbeda-beda.
 *
 * Enam materi selain "Apa Itu Excel?" masih `available: false` —
 * strukturnya (judul, kategori, urutan, dst) sudah lengkap dari STEP 5,
 * belum berubah di sini selain menambah field baru (category,
 * difficulty, tags, keywords, shortDescription) yang dibutuhkan STEP 6
 * untuk konsistensi data di seluruh lesson.
 */
export const level0Lessons: Lesson[] = [
  {
    id: "level-0/apa-itu-excel",
    slug: "apa-itu-excel",
    level: 0,
    category: "Dasar Excel",
    title: "Apa Itu Excel?",
    description:
      "Kenalan dengan Microsoft Excel: apa itu, dipakai untuk apa, dan kenapa skill ini berguna di kuliah maupun kerja.",
    shortDescription: "Kenalan dengan Excel dan kegunaannya sehari-hari.",
    order: 1,
    estimatedTime: "5 menit",
    difficulty: "Pemula",
    tags: ["excel", "pengenalan", "dasar"],
    keywords: ["apa itu excel", "microsoft excel", "belajar excel dari nol"],
    available: true,
    related: [
      { level: 0, slug: "mengenal-layar-excel" },
      { level: 0, slug: "workbook-worksheet" },
    ],
    content: [
      {
        type: "goal",
        text: "Setelah materi ini, kamu akan tahu apa itu Excel dan kenapa banyak orang memakainya.",
      },
      {
        type: "paragraph",
        text: "Microsoft Excel adalah program untuk membuat dan mengolah tabel. Kalau kamu pernah melihat daftar nilai, daftar belanja, atau catatan keuangan yang disusun dalam kotak-kotak berbaris rapi, kemungkinan besar kamu sedang melihat sesuatu yang bisa dikerjakan di Excel.",
      },
      {
        type: "paragraph",
        text: "Excel dipakai untuk menyimpan data, menghitung angka secara otomatis, dan merapikan informasi supaya mudah dibaca. Excel bukan untuk mengetik surat — itu tugas Word. Excel juga bukan untuk membuat slide presentasi — itu tugas PowerPoint. Excel fokus pada satu hal: tabel dan angka.",
      },
      {
        type: "paragraph",
        text: "Bedanya dengan menulis tabel di kertas atau di buku catatan: begitu satu angka berubah, Excel bisa langsung menghitung ulang semuanya sendiri. Itulah kenapa Excel jauh lebih cepat dipakai daripada menghitung manual satu per satu.",
      },
      {
        type: "visual",
        component: "excel-anatomy",
        caption:
          "Begini kira-kira tampilan Excel: bagian atas berisi menu (ribbon), dan bagian bawah berisi kotak-kotak tabel yang siap diisi.",
      },
      { type: "heading", text: "Dipakai untuk apa saja?", level: 2 },
      {
        type: "example",
        title: "Kuliah",
        situation:
          "Merekap nilai tugas dari beberapa mata kuliah, atau menyusun jadwal kuliah mingguan.",
      },
      {
        type: "example",
        title: "Kantor",
        situation:
          "Mencatat kehadiran karyawan, membuat laporan penjualan bulanan, atau menyusun slip gaji sederhana.",
      },
      {
        type: "example",
        title: "Bisnis",
        situation:
          "Mencatat stok barang yang masuk dan keluar, atau menghitung untung-rugi jualan online.",
      },
      {
        type: "example",
        title: "Sehari-hari",
        situation:
          "Mencatat pengeluaran bulanan, atau membuat daftar belanja lengkap dengan total harganya.",
      },
      {
        type: "summary",
        points: [
          "Excel adalah program untuk membuat dan mengolah tabel.",
          "Excel dipakai untuk mencatat data dan menghitung angka secara otomatis.",
          "Excel dipakai di hampir semua bidang: kuliah, kantor, bisnis, sampai catatan pribadi.",
          "Skill Excel banyak dicari karena hampir semua pekerjaan kantoran bersinggungan dengan data.",
        ],
      },
      {
        type: "quiz",
        question: "Excel paling cocok digunakan untuk apa?",
        options: [
          "Mengolah data dalam bentuk tabel",
          "Mengedit video",
          "Menggambar poster",
          "Merekam musik",
        ],
        answer: 0,
        explanation:
          "Excel dirancang khusus untuk mengolah tabel dan angka — bukan video, gambar, atau musik.",
      },
      {
        type: "quiz",
        question: "Kalau kamu ingin menulis surat resmi, program apa yang lebih cocok?",
        options: ["Excel", "Word", "Keduanya sama saja"],
        answer: 1,
        explanation:
          "Word dirancang khusus untuk dokumen teks seperti surat. Excel bukan pilihan yang pas untuk ini.",
      },
      {
        type: "quiz",
        question: "Manakah yang BUKAN contoh penggunaan Excel sehari-hari?",
        options: [
          "Mencatat pengeluaran bulanan",
          "Merekap nilai ujian",
          "Menggambar poster promosi",
          "Menghitung stok barang toko",
        ],
        answer: 2,
        explanation:
          "Menggambar poster lebih cocok dikerjakan di aplikasi desain, bukan Excel — sisanya semua soal tabel dan angka.",
      },
    ],
  },
  {
    id: "level-0/mengenal-layar-excel",
    slug: "mengenal-layar-excel",
    level: 0,
    category: "Dasar Excel",
    title: "Mengenal Layar Excel",
    description: "Berkenalan dengan ribbon, menu, dan bagian-bagian layar Excel.",
    shortDescription: "Berkenalan dengan ribbon, menu, dan bagian-bagian layar Excel.",
    order: 2,
    estimatedTime: "5 menit",
    difficulty: "Pemula",
    tags: ["excel", "ribbon", "menu", "tampilan"],
    keywords: ["ribbon excel", "menu excel", "tampilan layar excel"],
    available: false,
  },
  {
    id: "level-0/workbook-worksheet",
    slug: "workbook-worksheet",
    level: 0,
    category: "Dasar Excel",
    title: "Workbook & Worksheet",
    description: "Bedanya \"buku\" dan \"halaman\" di dalam satu file Excel.",
    shortDescription: "Bedanya \"buku\" dan \"halaman\" di dalam satu file Excel.",
    order: 3,
    estimatedTime: "4 menit",
    difficulty: "Pemula",
    tags: ["excel", "workbook", "worksheet", "sheet"],
    keywords: ["workbook adalah", "worksheet adalah", "sheet excel"],
    available: false,
  },
  {
    id: "level-0/row-column-cell",
    slug: "row-column-cell",
    level: 0,
    category: "Dasar Excel",
    title: "Row, Column & Cell",
    description: "Tiga istilah paling dasar yang akan terus kamu pakai.",
    shortDescription: "Tiga istilah paling dasar yang akan terus kamu pakai.",
    order: 4,
    estimatedTime: "5 menit",
    difficulty: "Pemula",
    tags: ["excel", "row", "column", "cell"],
    keywords: ["row adalah", "column adalah", "cell excel"],
    available: false,
  },
  {
    id: "level-0/range",
    slug: "range",
    level: 0,
    category: "Dasar Excel",
    title: "Mengenal Range",
    description: "Cara menyebut sekumpulan kotak sekaligus.",
    shortDescription: "Cara menyebut sekumpulan kotak sekaligus.",
    order: 5,
    estimatedTime: "4 menit",
    difficulty: "Pemula",
    tags: ["excel", "range"],
    keywords: ["range excel adalah", "cara menulis range"],
    available: false,
  },
  {
    id: "level-0/formula-bar",
    slug: "formula-bar",
    level: 0,
    category: "Dasar Excel",
    title: "Formula Bar",
    description: "Tempat rumus Excel benar-benar bekerja.",
    shortDescription: "Tempat rumus Excel benar-benar bekerja.",
    order: 6,
    estimatedTime: "4 menit",
    difficulty: "Pemula",
    tags: ["excel", "formula bar"],
    keywords: ["formula bar adalah", "letak formula bar"],
    available: false,
  },
  {
    id: "level-0/latihan-file-pertama",
    slug: "latihan-file-pertama",
    level: 0,
    category: "Dasar Excel",
    title: "Latihan: Membuat & Menyimpan File Pertamamu",
    description: "Praktik langsung: mengisi, menyimpan, dan membuka file Excel.",
    shortDescription: "Praktik langsung: mengisi, menyimpan, dan membuka file Excel.",
    order: 7,
    estimatedTime: "8 menit",
    difficulty: "Pemula",
    tags: ["excel", "latihan", "menyimpan file"],
    keywords: ["cara menyimpan file excel", "cara membuka file excel"],
    available: false,
  },
];
