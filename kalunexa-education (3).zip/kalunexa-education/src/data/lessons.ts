import type { LessonPreview } from "@/lib/types";

/**
 * DATA SEMENTARA (MOCK DATA) — khusus untuk kartu "Materi Populer" di
 * homepage. Ini beda dari src/data/lessons/*.ts (isi materi sungguhan
 * yang dipakai sistem lesson STEP 6) — file ini cuma untuk pratinjau
 * marketing di homepage & titik masuk ke halaman Rumus.
 *
 * CATATAN STEP 6: kategori di bawah disamakan dengan daftar kategori
 * resmi di src/lib/types.ts (LessonCategory), supaya hanya ada SATU
 * daftar kategori di seluruh website, bukan dua daftar yang berbeda
 * seperti sebelumnya. SUM sekarang mengarah langsung ke halaman
 * materinya yang sungguhan (dibangun di STEP 6), sisanya masih
 * mengarah ke halaman Rumus umum karena materinya belum ditulis.
 */
export const lessonPreviews: LessonPreview[] = [
  {
    name: "SUM",
    category: "Rumus Dasar",
    description: "Menjumlahkan data dengan cepat, tanpa kalkulator.",
    level: "Level 3",
    available: true,
    href: "/belajar/level-3/sum",
  },
  {
    name: "COUNTIF",
    category: "Rumus Logika",
    description: "Menghitung jumlah data yang memenuhi satu syarat.",
    level: "Level 4",
    available: false,
  },
  {
    name: "SUMIF",
    category: "Rumus Logika",
    description: "Menjumlahkan data yang memenuhi syarat tertentu.",
    level: "Level 4",
    available: false,
  },
  {
    name: "XLOOKUP",
    category: "Lookup",
    description: "Mengambil data dari tabel lain secara otomatis.",
    level: "Level 5",
    available: false,
  },
  {
    name: "FILTER",
    category: "Data",
    description: "Menyaring data sesuai kriteria yang kamu tentukan.",
    level: "Level 6",
    available: false,
  },
  {
    name: "Pivot Table",
    category: "Pivot Table",
    description: "Meringkas ribuan baris data jadi laporan singkat.",
    level: "Level 7",
    available: false,
  },
];
