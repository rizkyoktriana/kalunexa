import type { RoadmapLevel } from "@/lib/types";

/**
 * DATA SEMENTARA (MOCK DATA)
 * --------------------------
 * Ini bukan database sungguhan. Ini hanya daftar level yang ditulis
 * langsung di dalam kode, supaya tampilan roadmap bisa dibangun dan
 * dilihat dulu tanpa perlu menyiapkan database.
 *
 * "status" di bawah ini juga contoh sementara (Level 0 & 1 dibuat
 * "selesai" dan Level 2 "berjalan" hanya untuk menunjukkan bagaimana
 * tampilannya nanti). Belum ada sistem yang benar-benar mencatat
 * progress pengguna — itu dikerjakan di tahap berikutnya (Supabase).
 */
export const roadmapLevels: RoadmapLevel[] = [
  {
    number: 0,
    title: "Kenalan dengan Excel",
    description: "Tidak takut lagi membuka Excel.",
    stage: "dasar",
    status: "selesai",
  },
  {
    number: 1,
    title: "Dasar Mengetik & Mengatur Data",
    description: "Nyaman mengisi dan mengatur data di Excel.",
    stage: "dasar",
    status: "selesai",
  },
  {
    number: 2,
    title: "Merapikan Tampilan & Data Sederhana",
    description: "Tabel jadi rapi, mudah diurutkan dan dicari.",
    stage: "dasar",
    status: "berjalan",
  },
  {
    number: 3,
    title: "Rumus Dasar",
    description: "Membiarkan Excel yang menghitung untukmu.",
    stage: "menengah",
    status: "belum-mulai",
  },
  {
    number: 4,
    title: "Rumus untuk Dunia Kerja",
    description: "Menghitung berdasarkan syarat dan logika.",
    stage: "menengah",
    status: "segera-hadir",
  },
  {
    number: 5,
    title: "Lookup & Pencarian Data",
    description: "Mengambil data dari tabel lain secara otomatis.",
    stage: "mahir",
    status: "segera-hadir",
  },
  {
    number: 6,
    title: "Merapikan & Menganalisis Data",
    description: "Data bersih dan bisa dibaca lewat grafik.",
    stage: "mahir",
    status: "segera-hadir",
  },
  {
    number: 7,
    title: "Pivot Table",
    description: "Meringkas ribuan baris data dalam hitungan menit.",
    stage: "siap-kerja",
    status: "segera-hadir",
  },
  {
    number: 8,
    title: "Excel untuk Kebutuhan Pekerjaan",
    description: "Menerapkan semua ilmu ke kasus kerja nyata.",
    stage: "siap-kerja",
    status: "segera-hadir",
  },
  {
    number: 9,
    title: "Project & Latihan Akhir",
    description: "Membuktikan kemampuanmu lewat project utuh.",
    stage: "siap-kerja",
    status: "segera-hadir",
  },
];

export const stageLabels: Record<RoadmapLevel["stage"], string> = {
  dasar: "Dasar",
  menengah: "Menengah",
  mahir: "Mahir",
  "siap-kerja": "Siap Kerja",
};
