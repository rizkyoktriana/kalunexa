"use client";

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";

/**
 * SIMULASI PROGRESS (STEP 5)
 * ---------------------------
 * Sesuai rencana STEP 2 Tahap A: progress belajar BELUM disimpan ke
 * database. Progress disimpan di localStorage browser pengguna sendiri
 * (bertahan walau tab ditutup, tapi hilang kalau pindah perangkat atau
 * membersihkan data browser). Ini murni "simulasi" pengganti sementara,
 * sampai Supabase (Tahap B) dipasang.
 *
 * Cara pakai di komponen lain:
 *   const { isComplete, markComplete } = useProgress();
 *   if (isComplete("level-0/apa-itu-excel")) { ... }
 *
 * Provider ini dipasang SEKALI di src/app/layout.tsx, jadi progress
 * bisa dibaca dari halaman mana pun (Navbar, halaman Level, halaman
 * Lesson) tanpa mengirim data lewat props berulang-ulang.
 */

const STORAGE_KEY = "kalunexa:progress:v1";

interface ProgressContextValue {
  isComplete: (lessonId: string) => boolean;
  markComplete: (lessonId: string) => void;
  markIncomplete: (lessonId: string) => void;
  /** Berapa banyak dari daftar id materi ini yang sudah selesai */
  countComplete: (lessonIds: string[]) => number;
}

const ProgressContext = createContext<ProgressContextValue | null>(null);

export function ProgressProvider({ children }: { children: ReactNode }) {
  const [completed, setCompleted] = useState<Record<string, boolean>>({});

  // Baca localStorage setelah komponen muncul di browser (bukan saat
  // render pertama di server), supaya tidak terjadi mismatch antara
  // tampilan server dan browser.
  useEffect(() => {
    try {
      const raw = window.localStorage.getItem(STORAGE_KEY);
      if (raw) setCompleted(JSON.parse(raw));
    } catch {
      // localStorage tidak tersedia (contoh: mode penyamaran ketat) — abaikan, progress hanya tidak tersimpan.
    }
  }, []);

  const persist = useCallback((next: Record<string, boolean>) => {
    setCompleted(next);
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
    } catch {
      // Gagal menyimpan — progress tetap jalan untuk sesi ini saja.
    }
  }, []);

  const markComplete = useCallback(
    (lessonId: string) => {
      persist({ ...completed, [lessonId]: true });
    },
    [completed, persist],
  );

  const markIncomplete = useCallback(
    (lessonId: string) => {
      const next = { ...completed };
      delete next[lessonId];
      persist(next);
    },
    [completed, persist],
  );

  const isComplete = useCallback(
    (lessonId: string) => Boolean(completed[lessonId]),
    [completed],
  );

  const countComplete = useCallback(
    (lessonIds: string[]) => lessonIds.filter((id) => completed[id]).length,
    [completed],
  );

  const value = useMemo(
    () => ({ isComplete, markComplete, markIncomplete, countComplete }),
    [isComplete, markComplete, markIncomplete, countComplete],
  );

  return (
    <ProgressContext.Provider value={value}>
      {children}
    </ProgressContext.Provider>
  );
}

export function useProgress(): ProgressContextValue {
  const ctx = useContext(ProgressContext);
  if (!ctx) {
    throw new Error("useProgress harus dipakai di dalam <ProgressProvider>");
  }
  return ctx;
}
