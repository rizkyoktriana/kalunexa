// Tipe data dipisah dari isinya (src/data), supaya struktur datanya
// konsisten di seluruh halaman. Ini bukan database — hanya "bentuk" data.

export type LevelStage = "dasar" | "menengah" | "mahir" | "siap-kerja";

export type LevelStatus = "selesai" | "berjalan" | "belum-mulai" | "segera-hadir";

export interface RoadmapLevel {
  /** Nomor level, 0 sampai 9 */
  number: number;
  /** Nama level, contoh: "Kenalan dengan Excel" */
  title: string;
  /** Satu kalimat penjelasan tujuan level */
  description: string;
  /** Kelompok tahap: dasar / menengah / mahir / siap-kerja */
  stage: LevelStage;
  /** Status sementara untuk keperluan tampilan (belum terhubung ke progress asli) */
  status: LevelStatus;
}

/* ------------------------------------------------------------------ */
/*  KATEGORI & TINGKAT KESULITAN MATERI (STEP 6)                       */
/*  Satu daftar ini dipakai di SELURUH website — homepage, halaman     */
/*  Rumus, dan sistem lesson — supaya tidak ada dua daftar kategori    */
/*  yang berbeda-beda di file yang berbeda (STEP 5 sempat begitu,      */
/*  sekarang disatukan).                                               */
/* ------------------------------------------------------------------ */
export type LessonCategory =
  | "Dasar Excel"
  | "Formatting"
  | "Rumus Dasar"
  | "Rumus Logika"
  | "Text"
  | "Date & Time"
  | "Lookup"
  | "Data"
  | "Statistik"
  | "Pivot Table"
  | "Shortcut"
  | "Administrasi"
  | "Excel untuk Kerja";

export type LessonDifficulty = "Pemula" | "Menengah" | "Mahir";

export interface LessonPreview {
  /** Nama rumus atau materi, contoh: "SUM" */
  name: string;
  category: LessonCategory;
  /** Deskripsi singkat, satu kalimat */
  description: string;
  /** Level tempat materi ini berada, contoh: "Level 3" */
  level: string;
  /** Apakah materinya sudah bisa dibuka (untuk versi awal, sebagian masih "Segera hadir") */
  available: boolean;
  /** Kalau materinya sudah punya halaman sungguhan, isi alamatnya di sini. Kosongkan untuk mengarah ke halaman Rumus umum. */
  href?: string;
}

/* ------------------------------------------------------------------ */
/*  SISTEM LESSON — CONTENT-DRIVEN (STEP 6)                            */
/*  ------------------------------------------------------------------ */
/*  Bayangkan seperti cetakan buku dan isi buku:                       */
/*    - Halaman lesson (src/app/belajar/[level]/[slug]/page.tsx) itu   */
/*      CETAKANNYA. Bentuknya selalu sama untuk semua materi.          */
/*    - Data di src/data/lessons/*.ts itu ISI BUKUNYA. Beda materi,    */
/*      beda isi, tapi dicetak lewat cetakan yang sama.                */
/*  Satu materi = satu ARRAY BLOK (ContentBlock[]). Urutan array =     */
/*  urutan tampil di halaman. Materi boleh punya kombinasi blok apa    */
/*  saja, sesuai kebutuhan — tidak semua materi wajib punya tabel,     */
/*  formula, atau tips yang sama.                                      */
/* ------------------------------------------------------------------ */

/** Satu bagian formula dan artinya, contoh: "G3" → "data yang dicari" */
export interface FormulaPart {
  part: string;
  meaning: string;
}

/** Data tabel bergaya Excel, dipakai di blok "table" maupun di dalam blok "example" */
export interface TableData {
  headers: string[];
  rows: string[][];
  caption?: string;
}

export type ContentBlock =
  | { type: "heading"; text: string; level?: 2 | 3 }
  /** Kotak "Setelah materi ini kamu bisa..." — biasanya di awal, tapi posisinya bebas */
  | { type: "goal"; text: string }
  | { type: "paragraph"; text: string }
  /** Ilustrasi bernama, dipetakan ke komponen di components/lessons (lihat VisualBlock.tsx) */
  | { type: "visual"; component: "excel-anatomy"; caption?: string }
  | { type: "image"; src: string; alt: string; caption?: string }
  | ({ type: "table" } & TableData)
  | {
      type: "formula";
      formula: string;
      result?: string;
      /** Penjelasan tiap bagian formula, contoh untuk XLOOKUP: G3, C3:C12, E3:E12 */
      parts?: FormulaPart[];
    }
  /** "Contoh Kasus": situasi + (opsional) data, formula, hasil, dan penjelasan */
  | {
      type: "example";
      title?: string;
      situation: string;
      table?: TableData;
      formula?: string;
      result?: string;
      explanation?: string;
    }
  | { type: "tip"; text: string }
  | { type: "warning"; text: string }
  | { type: "code"; code: string; language?: string }
  /** Satu pertanyaan quiz = satu blok. Taruh sebanyak yang dibutuhkan, di mana saja dalam urutan konten. */
  | {
      type: "quiz";
      question: string;
      options: string[];
      /** Index (mulai dari 0) dari `options` yang benar */
      answer: number;
      explanation: string;
    }
  | { type: "summary"; points: string[] };

/** Rujukan ke materi lain, dipakai untuk "Materi Terkait" (bukan hardcode link per halaman) */
export interface RelatedLessonRef {
  level: number;
  slug: string;
}

export interface Lesson {
  /** ID unik di seluruh website, contoh: "level-3/sum". Dipakai sebagai kunci progress. */
  id: string;
  /** Bagian terakhir dari URL, contoh: "sum" */
  slug: string;
  level: number;
  category: LessonCategory;
  title: string;
  /** Deskripsi lebih panjang (1-2 kalimat), dipakai untuk meta description SEO */
  description: string;
  /** Satu kalimat pendek, dipakai di kartu daftar materi */
  shortDescription: string;
  /** Urutan materi di dalam levelnya, dimulai dari 1. Menentukan navigasi sebelumnya/berikutnya secara otomatis. */
  order: number;
  estimatedTime: string;
  difficulty: LessonDifficulty;
  /** Disiapkan untuk fitur pencarian nanti (STEP 6 baru menyiapkan strukturnya) */
  tags: string[];
  keywords: string[];
  /** false = materinya belum ditulis, halaman menampilkan "segera hadir" */
  available: boolean;
  content?: ContentBlock[];
  /** Materi terkait, dirujuk lewat level+slug — bukan judul yang di-hardcode */
  related?: RelatedLessonRef[];
}
