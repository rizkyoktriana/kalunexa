// Daftar menu utama, dipakai bersama oleh Navbar dan Footer, supaya
// urutan dan nama menu selalu sama di dua tempat itu.
export const mainNav = [
  { label: "Belajar", href: "/belajar" },
  { label: "Latihan", href: "/latihan" },
  { label: "Rumus", href: "/rumus" },
  { label: "Shortcut", href: "/shortcut" },
  { label: "Tentang", href: "/tentang" },
];
