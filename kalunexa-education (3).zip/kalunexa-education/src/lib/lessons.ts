import type { Lesson } from "@/lib/types";
import { level0Lessons } from "@/data/lessons/level-0";
import { level3Lessons } from "@/data/lessons/level-3";

/**
 * "Peta jalan" dari nomor level ke data materinya. Supaya menambah
 * Level 1 nanti tinggal: (1) buat file data/lessons/level-1.ts berisi
 * array Lesson[] seperti level-0.ts / level-3.ts, (2) tambahkan satu
 * baris di sini. Tidak ada halaman atau komponen yang perlu diubah —
 * ini inti dari sistem "content-driven" yang dibangun di STEP 6.
 */
const lessonsByLevel: Record<number, Lesson[]> = {
  0: level0Lessons,
  3: level3Lessons,
};

export function getLevelLessons(level: number): Lesson[] {
  return lessonsByLevel[level] ?? [];
}

/** Apakah level ini sudah punya data materi sungguhan (dipakai roadmap untuk tahu mana yang bisa diklik). */
export function levelHasLessons(level: number): boolean {
  return getLevelLessons(level).length > 0;
}

export function getLessonBySlug(level: number, slug: string): Lesson | undefined {
  return getLevelLessons(level).find((lesson) => lesson.slug === slug);
}

/** Materi sebelum dan sesudah materi yang sedang dibuka, dihitung OTOMATIS dari `order` —
 *  bukan field previous/next yang ditulis manual di data (supaya urutan tidak pernah
 *  "ketinggalan" kalau suatu saat urutan materi diubah). */
export function getAdjacentLessons(level: number, order: number) {
  const lessons = getLevelLessons(level);
  return {
    previous: lessons.find((lesson) => lesson.order === order - 1) ?? null,
    next: lessons.find((lesson) => lesson.order === order + 1) ?? null,
  };
}

/** Menerjemahkan rujukan `lesson.related` (level+slug) menjadi Lesson sungguhan.
 *  Rujukan yang datanya tidak ditemukan otomatis diabaikan (lihat STEP 6 bagian Validation). */
export function getRelatedLessons(lesson: Lesson): Lesson[] {
  if (!lesson.related || lesson.related.length === 0) return [];
  return lesson.related
    .map((ref) => getLessonBySlug(ref.level, ref.slug))
    .filter((found): found is Lesson => Boolean(found));
}

export function lessonHref(lesson: Pick<Lesson, "level" | "slug">): string {
  return `/belajar/level-${lesson.level}/${lesson.slug}`;
}

export function levelHref(level: number): string {
  return `/belajar/level-${level}`;
}

/**
 * Mengubah potongan URL seperti "level-3" menjadi angka 3.
 * Mengembalikan null kalau formatnya tidak sesuai (misalnya "level-abc"
 * atau "level3" tanpa tanda hubung) — dipakai untuk memicu halaman
 * "tidak ditemukan" di src/app/belajar/[level]/*.
 */
export function parseLevelParam(param: string): number | null {
  const match = /^level-(\d+)$/.exec(param);
  if (!match) return null;
  return Number(match[1]);
}
