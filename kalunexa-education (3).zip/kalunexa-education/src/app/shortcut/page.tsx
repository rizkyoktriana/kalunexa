import { ComingSoon } from "@/components/ui/ComingSoon";

export default function ShortcutPage() {
  return (
    <ComingSoon
      title="Excel Shortcut"
      description="Daftar shortcut keyboard yang dikelompokkan per kategori akan dibangun di tahap berikutnya."
    />
  );
}
