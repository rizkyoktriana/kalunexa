import type { Metadata } from "next";
import { Plus_Jakarta_Sans, JetBrains_Mono } from "next/font/google";
import "./globals.css";
import { Navbar } from "@/components/layout/Navbar";
import { Footer } from "@/components/layout/Footer";
import { ProgressProvider } from "@/lib/progress-context";

// Font untuk teks biasa (judul & isi), sesuai design system STEP 3.
const jakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-jakarta",
  display: "swap",
});

// Font khusus untuk rumus & tombol keyboard, supaya jelas berbeda dari teks biasa.
const jetbrainsMono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-jetbrains",
  display: "swap",
});

export const metadata: Metadata = {
  title: "Kalunexa Education — Learn Excel. Build Your Skills.",
  description:
    "Belajar Excel dari nol, pelan-pelan, sampai siap dipakai untuk kuliah, magang, dan kerja. Tanpa istilah rumit.",
};

/**
 * Layout utama: Navbar → isi halaman ({children}) → Footer.
 * Karena ditaruh di sini (bukan di tiap halaman), setiap halaman baru
 * yang dibuat nanti (Belajar, Latihan, dst.) OTOMATIS punya Navbar
 * dan Footer yang sama, tanpa perlu menulis ulang.
 */
export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="id">
      <body
        className={`${jakarta.variable} ${jetbrainsMono.variable} flex min-h-screen flex-col font-sans antialiased`}
      >
        <ProgressProvider>
          <Navbar />
          <main className="flex-1">{children}</main>
          <Footer />
        </ProgressProvider>
      </body>
    </html>
  );
}
