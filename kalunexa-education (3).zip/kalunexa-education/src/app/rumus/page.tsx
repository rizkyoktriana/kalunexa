import { ComingSoon } from "@/components/ui/ComingSoon";

export default function RumusPage() {
  return (
    <ComingSoon
      title="Rumus Excel"
      description="Kamus rumus lengkap dengan pencarian dan kategori akan dibangun di tahap berikutnya."
    />
  );
}
