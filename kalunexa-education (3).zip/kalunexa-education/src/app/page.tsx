import { Hero } from "@/components/home/Hero";
import { Introduction } from "@/components/home/Introduction";
import { RoadmapPreview } from "@/components/home/RoadmapPreview";
import { LessonsPreview } from "@/components/home/LessonsPreview";
import { CtaSection } from "@/components/home/CtaSection";

/**
 * Homepage: Hero → Introduction (masalah pengguna) → Roadmap Preview
 * → Materi Preview → CTA. Sesuai kerangka STEP 4 (poin 8).
 *
 * Halaman ini hanya "menyusun" section-section yang masing-masing
 * dibuat di src/components/home/. Kalau nanti section-nya ingin
 * diubah urutannya, cukup ubah urutan di sini.
 */
export default function HomePage() {
  return (
    <>
      <Hero />
      <Introduction />
      <RoadmapPreview />
      <LessonsPreview />
      <CtaSection />
    </>
  );
}
