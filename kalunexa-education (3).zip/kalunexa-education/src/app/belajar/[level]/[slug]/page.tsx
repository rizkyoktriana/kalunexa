import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { roadmapLevels } from "@/data/roadmap";
import {
  getLevelLessons,
  getLessonBySlug,
  getAdjacentLessons,
  getRelatedLessons,
  parseLevelParam,
} from "@/lib/lessons";
import { Breadcrumb } from "@/components/lessons/Breadcrumb";
import { LessonPositionBar } from "@/components/lessons/LessonPositionBar";
import { LessonNav } from "@/components/lessons/LessonNav";
import { ContentRenderer } from "@/components/lessons/blocks/ContentRenderer";
import { Badge } from "@/components/ui/Badge";
import { RelatedLessons } from "@/components/lessons/RelatedLessons";
import { LessonCompletion } from "@/components/lessons/LessonCompletion";
import { LessonPrevNext } from "@/components/lessons/LessonPrevNext";
import { LessonUnavailable } from "@/components/lessons/LessonUnavailable";

interface PageProps {
  params: Promise<{ level: string; slug: string }>;
}

/**
 * TEMPLATE LESSON UNIVERSAL (STEP 6)
 * -------------------------------------
 * INI ADALAH "CETAKANNYA". Satu file ini menampilkan SUM, AVERAGE,
 * COUNT, materi Level 0, dan materi apa pun yang ditambahkan nanti —
 * tidak ada satu baris kode pun di sini yang tahu atau peduli materi
 * mana yang sedang dibuka. Semua yang membedakan satu materi dari
 * materi lain datang dari data (src/data/lessons/*.ts).
 *
 * Menambah materi baru = menambah objek Lesson baru di data. TIDAK
 * PERNAH menyentuh file ini. Itulah bukti sistemnya benar-benar
 * data-driven (lihat STEP 6, bagian 31: test utama).
 */
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { level: levelParam, slug } = await params;
  const level = parseLevelParam(levelParam);
  const lesson = level !== null ? getLessonBySlug(level, slug) : undefined;

  if (!lesson) return { title: "Materi | Kalunexa Education" };

  return {
    title: `${lesson.title} — ${lesson.category} | Kalunexa Education`,
    description: lesson.description,
  };
}

export default async function LessonPage({ params }: PageProps) {
  const { level: levelParam, slug } = await params;
  const level = parseLevelParam(levelParam);

  if (level === null) {
    notFound();
  }

  const lesson = getLessonBySlug(level, slug);
  if (!lesson) {
    notFound();
  }

  const levelInfo = roadmapLevels.find((l) => l.number === level);
  const lessons = getLevelLessons(level);
  const { previous, next } = getAdjacentLessons(level, lesson.order);
  const allLessonIdsInLevel = lessons.map((l) => l.id);
  const related = getRelatedLessons(lesson);
  const levelLabel = levelInfo ? `Level ${level}: ${levelInfo.title}` : `Level ${level}`;

  return (
    <div>
      <LessonPositionBar levelLabel={`Level ${level}`} order={lesson.order} total={lessons.length} />

      <div className="mx-auto flex max-w-page gap-8 px-5 py-8 sm:py-10">
        <LessonNav levelLabel={levelLabel} lessons={lessons} currentSlug={slug} />

        <main className="min-w-0 flex-1">
          <Breadcrumb
            items={[
              { label: "Belajar", href: "/belajar" },
              { label: `Level ${level}`, href: `/belajar/level-${level}` },
              { label: lesson.title },
            ]}
          />

          <div className="mt-6 max-w-2xl">
            {lesson.available && lesson.content ? (
              <article>
                <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-muted">
                  <span>{lesson.estimatedTime}</span>
                  <span aria-hidden="true">·</span>
                  <span>{lesson.category}</span>
                  <Badge tone="neutral">{lesson.difficulty}</Badge>
                </div>
                <h1 className="mt-2 text-3xl font-bold text-foreground">{lesson.title}</h1>

                <div className="mt-6">
                  <ContentRenderer blocks={lesson.content} />
                </div>

                {related.length > 0 && (
                  <div className="mt-10">
                    <RelatedLessons lessons={related} />
                  </div>
                )}

                <div className="mt-10">
                  <LessonCompletion
                    lesson={lesson}
                    next={next}
                    allLessonIdsInLevel={allLessonIdsInLevel}
                  />
                </div>
              </article>
            ) : (
              <LessonUnavailable lesson={lesson} />
            )}

            <div className="mt-10">
              <LessonPrevNext level={level} previous={previous} next={next} />
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
