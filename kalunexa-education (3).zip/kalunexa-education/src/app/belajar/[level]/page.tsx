import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { roadmapLevels } from "@/data/roadmap";
import { getLevelLessons, parseLevelParam } from "@/lib/lessons";
import { Breadcrumb } from "@/components/lessons/Breadcrumb";
import { LevelLessonList } from "@/components/lessons/LevelLessonList";

interface PageProps {
  params: Promise<{ level: string }>;
}

/**
 * HALAMAN OVERVIEW LEVEL — GENERIK (STEP 6)
 * -------------------------------------------
 * Satu file ini melayani /belajar/level-0, /belajar/level-3, dan
 * level manapun nanti — bukan satu file per level seperti STEP 5.
 * "level" di URL diurai lewat parseLevelParam ("level-3" → 3), lalu
 * dicocokkan ke data roadmap dan data materinya.
 */
export async function generateMetadata({ params }: PageProps): Promise<Metadata> {
  const { level: levelParam } = await params;
  const level = parseLevelParam(levelParam);
  const info = level !== null ? roadmapLevels.find((l) => l.number === level) : undefined;

  return {
    title: info
      ? `Level ${info.number} — ${info.title} | Kalunexa Education`
      : "Level | Kalunexa Education",
  };
}

export default async function LevelPage({ params }: PageProps) {
  const { level: levelParam } = await params;
  const level = parseLevelParam(levelParam);

  if (level === null) {
    notFound();
  }

  const info = roadmapLevels.find((l) => l.number === level);
  if (!info) {
    notFound();
  }

  const lessons = getLevelLessons(level);
  const totalMinutes = lessons.reduce(
    (sum, l) => sum + (parseInt(l.estimatedTime, 10) || 0),
    0,
  );

  return (
    <div className="mx-auto max-w-3xl px-5 py-10 sm:py-14">
      <Breadcrumb
        items={[{ label: "Belajar", href: "/belajar" }, { label: `Level ${info.number}` }]}
      />

      <p className="mt-4 text-sm font-semibold text-primary-strong">Level {info.number}</p>
      <h1 className="mt-1 text-3xl font-bold text-foreground sm:text-4xl">{info.title}</h1>
      <p className="mt-3 max-w-xl text-muted">{info.description}</p>

      {lessons.length > 0 ? (
        <>
          <p className="mt-4 text-sm text-muted">
            {lessons.length} materi · sekitar {totalMinutes} menit total
          </p>
          <div className="mt-8">
            <LevelLessonList lessons={lessons} />
          </div>
        </>
      ) : (
        <div className="mt-8 rounded-card border border-dashed border-border bg-surface-alt p-8 text-center">
          <p className="text-xs font-semibold uppercase tracking-wide text-muted">
            Segera hadir
          </p>
          <p className="mx-auto mt-2 max-w-sm text-muted">
            Materi untuk level ini sedang disiapkan.
          </p>
        </div>
      )}
    </div>
  );
}
