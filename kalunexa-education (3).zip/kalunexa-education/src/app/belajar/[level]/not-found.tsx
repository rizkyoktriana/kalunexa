import { Button } from "@/components/ui/Button";

/**
 * Dipicu lewat notFound() di dalam src/app/belajar/[level]/* —
 * baik untuk alamat level yang salah format ("level-abc") maupun
 * level yang tidak terdaftar. Lebih spesifik daripada 404 umum
 * (src/app/not-found.tsx), sesuai STEP 6 bagian 26.
 */
export default function LevelNotFound() {
  return (
    <div className="mx-auto flex max-w-page flex-col items-center px-5 py-24 text-center">
      <h1 className="text-3xl font-bold text-foreground">Materi tidak ditemukan</h1>
      <p className="mt-3 max-w-md text-muted">
        Alamatnya mungkin keliru, atau materinya sudah dipindah.
      </p>
      <div className="mt-8">
        <Button href="/belajar">Kembali ke Daftar Materi</Button>
      </div>
    </div>
  );
}
