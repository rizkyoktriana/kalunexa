import type { Metadata } from "next";
import { roadmapLevels } from "@/data/roadmap";
import { RoadmapLevelsWithLiveStatus } from "@/components/roadmap/RoadmapLevelsWithLiveStatus";

export const metadata: Metadata = {
  title: "Belajar Excel — Roadmap | Kalunexa Education",
};

/**
 * Halaman "Belajar": daftar 10 level (STEP 1). Level yang sudah punya
 * data materi (dicek lewat getLevelLessons di dalam
 * RoadmapLevelsWithLiveStatus — saat ini Level 0 dan Level 3) otomatis
 * bisa diklik dengan status hidup; level lain masih pratinjau
 * ("Segera hadir"). Tidak ada daftar level yang di-hardcode di sini.
 */
export default function BelajarPage() {
  return (
    <div className="mx-auto max-w-page px-5 py-10 sm:py-14">
      <p className="text-xs font-semibold uppercase tracking-wide text-primary-strong">
        Roadmap
      </p>
      <h1 className="mt-1 text-3xl font-bold text-foreground sm:text-4xl">
        Belajar Excel
      </h1>
      <p className="mt-3 max-w-xl text-muted">
        Dari nol sampai siap kerja. Ikuti urutannya, atau mulai dari Level 0
        kalau kamu benar-benar baru.
      </p>

      <div className="mt-10">
        <RoadmapLevelsWithLiveStatus levels={roadmapLevels} />
      </div>
    </div>
  );
}
