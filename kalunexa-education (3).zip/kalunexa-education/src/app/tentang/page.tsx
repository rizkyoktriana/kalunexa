import { ComingSoon } from "@/components/ui/ComingSoon";

export default function TentangPage() {
  return (
    <ComingSoon
      title="Tentang Kalunexa"
      description="Cerita singkat tentang Kalunexa Education akan dilengkapi di tahap berikutnya."
    />
  );
}
