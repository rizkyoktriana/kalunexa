import { ComingSoon } from "@/components/ui/ComingSoon";

export default function LatihanPage() {
  return (
    <ComingSoon
      title="Halaman Latihan"
      description="Latihan pilihan ganda, tebak hasil rumus, dan studi kasus akan dibangun di tahap berikutnya."
    />
  );
}
