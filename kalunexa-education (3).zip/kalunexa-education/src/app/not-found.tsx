import { Button } from "@/components/ui/Button";

// Halaman 404 bawaan Next.js, dibuat ramah sesuai gaya bahasa Kalunexa
// (STEP 3, bagian 14: pesan error pakai bahasa manusia).
export default function NotFound() {
  return (
    <div className="mx-auto flex max-w-page flex-col items-center px-5 py-24 text-center">
      <h1 className="text-3xl font-bold text-foreground">
        Halaman ini tidak ketemu
      </h1>
      <p className="mt-3 max-w-md text-muted">
        Mungkin alamatnya keliru, atau halamannya sudah pindah.
      </p>
      <div className="mt-8">
        <Button href="/">Kembali ke Beranda</Button>
      </div>
    </div>
  );
}
