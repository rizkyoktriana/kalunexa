// Menghubungkan Tailwind CSS ke Next.js. Biasanya tidak perlu diubah.
const config = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};

export default config;
