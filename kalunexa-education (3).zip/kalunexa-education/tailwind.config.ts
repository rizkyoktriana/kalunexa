import type { Config } from "tailwindcss";

/**
 * Tailwind hanya "menerjemahkan" nama kelas (misalnya bg-primary-strong)
 * ke variabel warna yang ada di src/app/globals.css.
 *
 * Mau ganti warna, bentuk, atau bayangan?
 * Ubah nilainya di globals.css (bagian :root). File ini tidak perlu disentuh.
 */
const config: Config = {
  content: ["./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: {
          DEFAULT: "var(--color-primary)",
          strong: "var(--color-primary-strong)",
          deep: "var(--color-primary-deep)",
          soft: "var(--color-primary-soft)",
        },
        accent: {
          DEFAULT: "var(--color-accent)",
          soft: "var(--color-accent-soft)",
        },
        background: "var(--color-background)",
        "surface-alt": "var(--color-surface-alt)",
        card: "var(--color-card)",
        foreground: "var(--color-foreground)",
        muted: "var(--color-muted)",
        border: "var(--color-border)",
        // Tiga warna status di bawah disiapkan untuk tahap berikutnya
        // (quiz, pesan error, dan sebagainya).
        success: {
          DEFAULT: "var(--color-success)",
          soft: "var(--color-success-soft)",
        },
        warning: {
          DEFAULT: "var(--color-warning)",
          soft: "var(--color-warning-soft)",
        },
        danger: {
          DEFAULT: "var(--color-danger)",
          soft: "var(--color-danger-soft)",
        },
      },
      borderColor: {
        DEFAULT: "var(--color-border)",
      },
      borderRadius: {
        button: "var(--radius-button)",
        card: "var(--radius-card)",
        input: "var(--radius-input)",
        badge: "var(--radius-badge)",
      },
      boxShadow: {
        soft: "var(--shadow-soft)",
        hover: "var(--shadow-hover)",
      },
      fontFamily: {
        sans: [
          "var(--font-jakarta)",
          "ui-sans-serif",
          "system-ui",
          "sans-serif",
        ],
        mono: [
          "var(--font-jetbrains)",
          "ui-monospace",
          "SFMono-Regular",
          "Menlo",
          "monospace",
        ],
      },
      maxWidth: {
        page: "70rem",
      },
    },
  },
  plugins: [],
};

export default config;
